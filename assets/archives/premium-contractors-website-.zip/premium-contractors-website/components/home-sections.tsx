"use client"

import Link from 'next/link'
import Image from 'next/image'
import { motion, useInView } from 'framer-motion'
import { useRef } from 'react'
import { 
  ArrowRight, 
  Building2, 
  Hammer, 
  PaintBucket, 
  LayoutGrid, 
  CheckCircle2, 
  Quote,
  Phone,
  Star,
  Award,
  Shield,
  Clock,
  MapPin,
  Users,
  Zap
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { projects } from '@/lib/data/projects'
import { services } from '@/lib/data/services'
import { testimonials, companyStats } from '@/lib/data/company'

// Animation variants
const fadeInUp = {
  hidden: { opacity: 0, y: 30 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6, ease: 'easeOut' } }
}

const staggerContainer = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.1, delayChildren: 0.2 }
  }
}

const staggerItem = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.5, ease: 'easeOut' } }
}

// Stats Counter Component
function StatsCounter({ value, suffix = '', label }: { value: number; suffix?: string; label: string }) {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: '-100px' })
  
  return (
    <div ref={ref} className="text-center">
      <motion.div 
        initial={{ opacity: 0, scale: 0.5 }}
        animate={isInView ? { opacity: 1, scale: 1 } : { opacity: 0, scale: 0.5 }}
        transition={{ duration: 0.5, type: 'spring' }}
        className="font-[family-name:var(--font-playfair)] text-4xl md:text-5xl lg:text-6xl font-bold mb-2"
      >
        <motion.span
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : { opacity: 0 }}
        >
          {value}{suffix}
        </motion.span>
      </motion.div>
      <div className="text-sm uppercase tracking-wider opacity-80">
        {label}
      </div>
    </div>
  )
}

// Hero Section - Full Impact with Video/Image Background
export function HeroSection() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0">
        <Image
          src="/images/hero-construction.jpg"
          alt="Commercial construction site"
          fill
          className="object-cover"
          priority
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/60 to-black/40" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
      </div>
      
      <div className="container mx-auto px-4 lg:px-8 relative z-10 pt-32 pb-20">
        <div className="max-w-4xl">
          {/* Badge */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="inline-flex items-center gap-3 px-5 py-2.5 bg-white/10 backdrop-blur-sm border border-white/20 rounded-full mb-8"
          >
            <span className="w-2 h-2 bg-accent rounded-full animate-pulse" />
            <span className="text-sm font-medium text-white/90 tracking-wide">
              EXCELLENCE SINCE 1988 &bull; NEWARK, NJ
            </span>
          </motion.div>

          {/* Main headline */}
          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="font-[family-name:var(--font-playfair)] text-5xl md:text-6xl lg:text-7xl xl:text-8xl font-semibold text-white mb-6 leading-[1.1] text-shadow"
          >
            Commercial Construction
            <br />
            <span className="text-accent">Built to Perfection</span>
          </motion.h1>

          {/* Subtitle */}
          <motion.p
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-xl md:text-2xl text-white/80 max-w-2xl mb-10 leading-relaxed"
          >
            Trusted by Marriott, Hilton, and industry leaders for over three decades. 
            We deliver exceptional hotel, restaurant, and commercial construction 
            throughout New Jersey and New York.
          </motion.p>

          {/* CTAs */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="flex flex-col sm:flex-row items-start gap-4"
          >
            <Button asChild size="lg" className="bg-accent hover:bg-accent/90 text-accent-foreground font-semibold text-lg px-8 h-14 shadow-xl">
              <Link href="/contact">
                Request a Consultation
                <ArrowRight className="ml-2 w-5 h-5" />
              </Link>
            </Button>
            <Button asChild variant="outline" size="lg" className="text-lg px-8 h-14 border-white/30 text-white hover:bg-white/10 hover:border-white/50 bg-transparent">
              <Link href="/projects">
                View Our Portfolio
              </Link>
            </Button>
          </motion.div>

          {/* Quick Stats */}
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.5 }}
            className="mt-16 flex flex-wrap gap-8 md:gap-12"
          >
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-accent/20 rounded-full flex items-center justify-center">
                <Award className="w-6 h-6 text-accent" />
              </div>
              <div>
                <div className="text-2xl font-bold text-white">37+</div>
                <div className="text-sm text-white/60">Years Experience</div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-accent/20 rounded-full flex items-center justify-center">
                <Building2 className="w-6 h-6 text-accent" />
              </div>
              <div>
                <div className="text-2xl font-bold text-white">127+</div>
                <div className="text-sm text-white/60">Projects Completed</div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-accent/20 rounded-full flex items-center justify-center">
                <Star className="w-6 h-6 text-accent" />
              </div>
              <div>
                <div className="text-2xl font-bold text-white">4.9/5</div>
                <div className="text-sm text-white/60">Client Rating</div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Scroll indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1, duration: 0.5 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2"
      >
        <motion.div
          animate={{ y: [0, 8, 0] }}
          transition={{ duration: 1.5, repeat: Infinity }}
          className="w-6 h-10 border-2 border-white/30 rounded-full flex items-start justify-center p-1"
        >
          <div className="w-1.5 h-3 bg-accent rounded-full" />
        </motion.div>
      </motion.div>
    </section>
  )
}

// Clients/Trust Section - White Background
export function ClientsSection() {
  const clientLogos = [
    { name: 'Marriott', subtitle: 'Hotels & Resorts' },
    { name: 'Hilton', subtitle: 'Hotels Worldwide' },
    { name: "Wendy's", subtitle: 'Restaurant Chain' },
    { name: 'The Briad Group', subtitle: 'Hospitality Group' },
    { name: 'Signature Aviation', subtitle: 'Aviation Services' }
  ]
  
  return (
    <section className="py-20 bg-white border-b border-border">
      <div className="container mx-auto px-4 lg:px-8">
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: '-50px' }}
          variants={fadeInUp}
          className="text-center mb-12"
        >
          <p className="text-sm font-medium uppercase tracking-[0.2em] text-accent mb-2">
            Trusted Partnerships
          </p>
          <h2 className="font-[family-name:var(--font-playfair)] text-2xl md:text-3xl font-semibold text-foreground">
            Building Excellence for Industry Leaders
          </h2>
        </motion.div>

        <motion.div 
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={staggerContainer}
          className="flex flex-wrap items-center justify-center gap-12 md:gap-16 lg:gap-20"
        >
          {clientLogos.map((client) => (
            <motion.div 
              key={client.name}
              variants={staggerItem}
              className="text-center group cursor-default"
            >
              <div className="font-[family-name:var(--font-playfair)] text-2xl md:text-3xl font-semibold text-foreground/40 group-hover:text-accent transition-colors duration-300">
                {client.name}
              </div>
              <div className="text-xs text-muted-foreground mt-1 opacity-0 group-hover:opacity-100 transition-opacity">
                {client.subtitle}
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  )
}

// About Preview - Dark Section
export function AboutPreviewSection() {
  return (
    <section className="section-dark py-24 lg:py-32 relative overflow-hidden">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          {/* Content */}
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: '-100px' }}
            variants={fadeInUp}
          >
            <p className="text-sm font-medium uppercase tracking-[0.2em] text-accent mb-4">
              About Premium Contractors
            </p>
            <h2 className="font-[family-name:var(--font-playfair)] text-4xl md:text-5xl font-semibold text-white mb-6 leading-tight">
              Three Decades of
              <br />
              <span className="text-accent">Uncompromising Quality</span>
            </h2>
            <p className="text-lg text-white/70 mb-8 leading-relaxed">
              Founded in 1988 by Diniz Teixeira, Premium Contractors LLC has grown from 
              a small family business into one of the most respected commercial 
              construction companies in the New Jersey and New York metropolitan area.
            </p>
            <p className="text-lg text-white/70 mb-10 leading-relaxed">
              Our commitment to excellence has earned us long-term partnerships with 
              the hospitality industry&apos;s most prestigious brands, including Marriott, 
              Hilton, and major restaurant chains.
            </p>

            {/* Key Points */}
            <div className="grid sm:grid-cols-2 gap-4 mb-10">
              {[
                { icon: Shield, text: 'Licensed & Fully Insured' },
                { icon: Users, text: 'Expert Craftsmen Team' },
                { icon: Clock, text: 'On-Time Delivery' },
                { icon: Award, text: 'Award-Winning Quality' }
              ].map((item) => (
                <div key={item.text} className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-accent/20 rounded-lg flex items-center justify-center">
                    <item.icon className="w-5 h-5 text-accent" />
                  </div>
                  <span className="text-white/80">{item.text}</span>
                </div>
              ))}
            </div>

            <Button asChild size="lg" variant="outline" className="border-white/30 text-white hover:bg-white/10 hover:border-white/50 bg-transparent">
              <Link href="/about">
                Learn Our Story
                <ArrowRight className="ml-2 w-4 h-4" />
              </Link>
            </Button>
          </motion.div>

          {/* Image Grid */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.8 }}
            className="relative"
          >
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-4">
                <div className="aspect-[4/5] relative rounded-xl overflow-hidden">
                  <Image
                    src="/images/hotel-lobby.jpg"
                    alt="Luxury hotel lobby construction"
                    fill
                    className="object-cover"
                  />
                </div>
                <div className="aspect-square relative rounded-xl overflow-hidden">
                  <Image
                    src="/images/metal-framing.jpg"
                    alt="Metal framing work"
                    fill
                    className="object-cover"
                  />
                </div>
              </div>
              <div className="space-y-4 pt-8">
                <div className="aspect-square relative rounded-xl overflow-hidden">
                  <Image
                    src="/images/team-photo.jpg"
                    alt="Premium Contractors team"
                    fill
                    className="object-cover"
                  />
                </div>
                <div className="aspect-[4/5] relative rounded-xl overflow-hidden">
                  <Image
                    src="/images/restaurant-interior.jpg"
                    alt="Restaurant interior finish"
                    fill
                    className="object-cover"
                  />
                </div>
              </div>
            </div>

            {/* Floating Stats Card */}
            <div className="absolute -bottom-8 -left-8 bg-white p-6 rounded-xl shadow-2xl hidden lg:block">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 bg-accent rounded-full flex items-center justify-center">
                  <Building2 className="w-7 h-7 text-white" />
                </div>
                <div>
                  <div className="font-[family-name:var(--font-playfair)] text-3xl font-bold text-foreground">127+</div>
                  <div className="text-sm text-muted-foreground">Projects Delivered</div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}

// Services Section - White Background
export function ServicesSection() {
  const featuredServices = services.slice(0, 6)
  const iconMap: Record<string, React.ElementType> = {
    frame: Building2,
    layers: LayoutGrid,
    paintbrush: PaintBucket,
    grid3x3: LayoutGrid,
    box: Hammer,
  }

  return (
    <section className="py-24 lg:py-32 bg-white">
      <div className="container mx-auto px-4 lg:px-8">
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: '-100px' }}
          variants={fadeInUp}
          className="text-center mb-16"
        >
          <p className="text-sm font-medium uppercase tracking-[0.2em] text-accent mb-4">
            Our Expertise
          </p>
          <h2 className="font-[family-name:var(--font-playfair)] text-4xl md:text-5xl font-semibold text-foreground mb-6">
            Comprehensive Construction Services
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            From structural framing to final finishes, we provide complete commercial 
            construction solutions with unmatched precision and craftsmanship.
          </p>
        </motion.div>

        <motion.div 
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={staggerContainer}
          className="grid md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {featuredServices.map((service) => {
            const Icon = iconMap[service.icon] || Building2
            return (
              <motion.div key={service.slug} variants={staggerItem}>
                <Link
                  href={`/services/${service.slug}`}
                  className="group block p-8 bg-white border border-border rounded-xl hover:border-accent/50 hover:shadow-xl transition-all duration-300"
                >
                  <div className="w-14 h-14 bg-accent/10 rounded-xl flex items-center justify-center mb-6 group-hover:bg-accent group-hover:scale-110 transition-all duration-300">
                    <Icon className="w-7 h-7 text-accent group-hover:text-white transition-colors" />
                  </div>
                  <h3 className="font-[family-name:var(--font-playfair)] text-xl font-semibold text-foreground mb-3 group-hover:text-accent transition-colors">
                    {service.name}
                  </h3>
                  <p className="text-muted-foreground mb-4 leading-relaxed">
                    {service.shortDescription}
                  </p>
                  <span className="inline-flex items-center text-sm font-medium text-accent opacity-0 group-hover:opacity-100 transition-opacity">
                    Learn More <ArrowRight className="ml-1 w-4 h-4" />
                  </span>
                </Link>
              </motion.div>
            )
          })}
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.3 }}
          className="text-center mt-12"
        >
          <Button asChild size="lg" variant="outline" className="border-foreground/20 hover:bg-foreground hover:text-background">
            <Link href="/services">
              View All Services
              <ArrowRight className="ml-2 w-4 h-4" />
            </Link>
          </Button>
        </motion.div>
      </div>
    </section>
  )
}

// Featured Projects - Dark Section with Images
export function FeaturedProjectsSection() {
  const featuredProjects = projects.filter(p => p.featured).slice(0, 3)
  const projectImages = [
    '/images/hotel-lobby.jpg',
    '/images/restaurant-interior.jpg',
    '/images/aerial-building.jpg'
  ]

  return (
    <section className="section-dark py-24 lg:py-32 relative">
      <div className="container mx-auto px-4 lg:px-8">
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: '-100px' }}
          variants={fadeInUp}
          className="text-center mb-16"
        >
          <p className="text-sm font-medium uppercase tracking-[0.2em] text-accent mb-4">
            Our Portfolio
          </p>
          <h2 className="font-[family-name:var(--font-playfair)] text-4xl md:text-5xl font-semibold text-white mb-6">
            Featured Projects
          </h2>
          <p className="text-lg text-white/70 max-w-2xl mx-auto">
            Explore our recent commercial construction projects across 
            New Jersey and New York.
          </p>
        </motion.div>

        <motion.div 
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={staggerContainer}
          className="grid md:grid-cols-2 lg:grid-cols-3 gap-8"
        >
          {featuredProjects.map((project, index) => (
            <motion.div key={project.slug} variants={staggerItem}>
              <Link 
                href={`/projects/${project.slug}`}
                className="group block bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl overflow-hidden hover:border-accent/50 transition-all duration-300 hover:shadow-2xl hover:shadow-accent/10"
              >
                <div className="aspect-[4/3] relative overflow-hidden">
                  <Image
                    src={projectImages[index % projectImages.length]}
                    alt={project.name}
                    fill
                    className="object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                  <div className="absolute bottom-4 left-4 right-4">
                    <span className="inline-block px-3 py-1 text-xs font-medium bg-accent text-white rounded-full mb-2">
                      {project.type}
                    </span>
                    <h3 className="font-[family-name:var(--font-playfair)] text-xl font-semibold text-white">
                      {project.name}
                    </h3>
                  </div>
                </div>
                <div className="p-6">
                  <div className="flex items-center gap-2 text-white/60 text-sm mb-3">
                    <MapPin className="w-4 h-4" />
                    {project.location}
                  </div>
                  <p className="text-white/70 text-sm mb-4 line-clamp-2">
                    {project.description}
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {project.scope.slice(0, 3).map((service) => (
                      <span key={service} className="text-xs text-white/50 bg-white/5 px-2 py-1 rounded">
                        {service}
                      </span>
                    ))}
                  </div>
                </div>
              </Link>
            </motion.div>
          ))}
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.3 }}
          className="text-center mt-12"
        >
          <Button asChild size="lg" variant="outline" className="border-white/30 text-white hover:bg-white/10 hover:border-white/50 bg-transparent">
            <Link href="/projects">
              View Full Portfolio
              <ArrowRight className="ml-2 w-4 h-4" />
            </Link>
          </Button>
        </motion.div>
      </div>
    </section>
  )
}

// Testimonial Section - White Background
export function TestimonialSection() {
  return (
    <section className="py-24 lg:py-32 bg-white relative overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute top-0 left-0 w-64 h-64 bg-accent/5 rounded-full blur-3xl -translate-x-1/2 -translate-y-1/2" />
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-accent/5 rounded-full blur-3xl translate-x-1/2 translate-y-1/2" />
      
      <div className="container mx-auto px-4 lg:px-8 relative z-10">
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: '-100px' }}
          variants={fadeInUp}
          className="max-w-4xl mx-auto"
        >
          <div className="text-center mb-12">
            <p className="text-sm font-medium uppercase tracking-[0.2em] text-accent mb-4">
              Client Testimonials
            </p>
            <h2 className="font-[family-name:var(--font-playfair)] text-4xl md:text-5xl font-semibold text-foreground">
              What Our Clients Say
            </h2>
          </div>

          <div className="bg-secondary/50 border border-border rounded-2xl p-8 md:p-12 relative">
            <Quote className="w-16 h-16 text-accent/20 absolute top-8 left-8" />
            
            <div className="relative z-10">
              {/* Stars */}
              <div className="flex items-center justify-center gap-1 mb-8">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-6 h-6 fill-accent text-accent" />
                ))}
              </div>
              
              <blockquote className="font-[family-name:var(--font-playfair)] text-2xl md:text-3xl text-foreground text-center mb-8 leading-relaxed">
                &ldquo;{testimonials[0].quote}&rdquo;
              </blockquote>
              
              <div className="flex items-center justify-center gap-4">
                <div className="w-14 h-14 bg-accent rounded-full flex items-center justify-center">
                  <span className="font-semibold text-white text-xl">
                    {testimonials[0].author.charAt(0)}
                  </span>
                </div>
                <div className="text-left">
                  <div className="font-semibold text-foreground text-lg">
                    {testimonials[0].author}
                  </div>
                  <div className="text-muted-foreground">
                    {testimonials[0].title}, {testimonials[0].company}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  )
}

// Stats Section - Dark with Impact
export function StatsSection() {
  return (
    <section className="section-dark py-20 lg:py-24">
      <div className="container mx-auto px-4 lg:px-8">
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: '-100px' }}
          variants={staggerContainer}
          className="grid grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12"
        >
          <motion.div variants={staggerItem}>
            <StatsCounter value={37} suffix="+" label="Years of Excellence" />
          </motion.div>
          <motion.div variants={staggerItem}>
            <StatsCounter value={127} suffix="+" label="Projects Completed" />
          </motion.div>
          <motion.div variants={staggerItem}>
            <StatsCounter value={45} suffix="+" label="Client Partners" />
          </motion.div>
          <motion.div variants={staggerItem}>
            <StatsCounter value={100} suffix="%" label="Client Satisfaction" />
          </motion.div>
        </motion.div>
      </div>
    </section>
  )
}

// Why Choose Us Section - White Background
export function WhyChooseUsSection() {
  const reasons = [
    {
      icon: Award,
      title: '37+ Years of Experience',
      description: 'Established in 1988, we bring decades of expertise to every project, ensuring quality and reliability.'
    },
    {
      icon: Shield,
      title: 'Licensed & Fully Insured',
      description: 'Complete peace of mind with comprehensive insurance coverage and all required licenses.'
    },
    {
      icon: Users,
      title: 'Expert Craftsmen',
      description: 'Our skilled team delivers precision workmanship on every project, from framing to finishing.'
    },
    {
      icon: Clock,
      title: 'On-Time Delivery',
      description: 'We understand the value of your time. Our projects are completed on schedule, every time.'
    },
    {
      icon: Zap,
      title: 'Turnkey Solutions',
      description: 'From initial consultation to final walkthrough, we handle every aspect of your construction project.'
    },
    {
      icon: Building2,
      title: 'Industry Partnerships',
      description: 'Trusted by Marriott, Hilton, and major hospitality brands for their construction needs.'
    }
  ]

  return (
    <section className="py-24 lg:py-32 bg-white">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          {/* Image Side */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.8 }}
            className="relative order-2 lg:order-1"
          >
            <div className="aspect-[4/5] relative rounded-2xl overflow-hidden">
              <Image
                src="/images/drywall-work.jpg"
                alt="Professional drywall installation"
                fill
                className="object-cover"
              />
            </div>
            
            {/* Floating Card */}
            <div className="absolute -bottom-6 -right-6 bg-accent text-white p-6 rounded-xl shadow-2xl max-w-[240px] hidden md:block">
              <div className="flex items-center gap-2 mb-2">
                <Star className="w-5 h-5 fill-white" />
                <span className="font-bold text-lg">4.9/5</span>
              </div>
              <p className="text-sm text-white/90">
                Average rating from 127+ completed projects
              </p>
            </div>
          </motion.div>

          {/* Content Side */}
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: '-100px' }}
            variants={fadeInUp}
            className="order-1 lg:order-2"
          >
            <p className="text-sm font-medium uppercase tracking-[0.2em] text-accent mb-4">
              Why Choose Us
            </p>
            <h2 className="font-[family-name:var(--font-playfair)] text-4xl md:text-5xl font-semibold text-foreground mb-6 leading-tight">
              The Premium
              <br />
              <span className="text-accent">Difference</span>
            </h2>
            <p className="text-lg text-muted-foreground mb-10 leading-relaxed">
              We don&apos;t just build structures—we build lasting relationships 
              through exceptional quality, transparent communication, and 
              unwavering commitment to your success.
            </p>

            <div className="grid sm:grid-cols-2 gap-6">
              {reasons.slice(0, 4).map((reason) => (
                <div key={reason.title} className="flex gap-4">
                  <div className="w-12 h-12 bg-accent/10 rounded-xl flex items-center justify-center shrink-0">
                    <reason.icon className="w-6 h-6 text-accent" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-foreground mb-1">
                      {reason.title}
                    </h3>
                    <p className="text-sm text-muted-foreground">
                      {reason.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}

// CTA Section - Final Call to Action
export function CTASection() {
  return (
    <section className="relative py-24 lg:py-32 overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0">
        <Image
          src="/images/aerial-building.jpg"
          alt="Commercial building aerial view"
          fill
          className="object-cover"
        />
        <div className="absolute inset-0 bg-primary/90" />
      </div>

      <div className="container mx-auto px-4 lg:px-8 relative z-10">
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: '-100px' }}
          variants={fadeInUp}
          className="max-w-3xl mx-auto text-center"
        >
          <p className="text-sm font-medium uppercase tracking-[0.2em] text-accent mb-4">
            Start Your Project
          </p>
          <h2 className="font-[family-name:var(--font-playfair)] text-4xl md:text-5xl lg:text-6xl font-semibold text-white mb-6 leading-tight">
            Ready to Build
            <br />
            <span className="text-accent">Something Exceptional?</span>
          </h2>
          <p className="text-xl text-white/80 mb-10 leading-relaxed">
            Let&apos;s discuss your vision. Our team is ready to bring your 
            commercial construction project to life with the quality and 
            professionalism you deserve.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Button asChild size="lg" className="bg-accent hover:bg-accent/90 text-accent-foreground font-semibold text-lg px-8 h-14 shadow-xl">
              <Link href="/contact">
                Schedule a Consultation
                <ArrowRight className="ml-2 w-5 h-5" />
              </Link>
            </Button>
            <Button asChild size="lg" variant="outline" className="border-white/30 text-white hover:bg-white/10 hover:border-white/50 bg-transparent text-lg px-8 h-14">
              <Link href="tel:+19735585226">
                <Phone className="mr-2 w-5 h-5" />
                (973) 558-5226
              </Link>
            </Button>
          </div>

          {/* Trust indicators */}
          <div className="flex flex-wrap items-center justify-center gap-8 mt-12 pt-12 border-t border-white/20">
            <div className="flex items-center gap-2 text-white/70">
              <CheckCircle2 className="w-5 h-5 text-accent" />
              <span>Free Consultation</span>
            </div>
            <div className="flex items-center gap-2 text-white/70">
              <CheckCircle2 className="w-5 h-5 text-accent" />
              <span>Detailed Proposals</span>
            </div>
            <div className="flex items-center gap-2 text-white/70">
              <CheckCircle2 className="w-5 h-5 text-accent" />
              <span>No Obligation</span>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
