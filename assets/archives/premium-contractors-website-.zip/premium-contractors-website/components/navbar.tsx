"use client"

import { useState, useEffect } from 'react'
import Link from 'next/link'
import Image from 'next/image'
import { motion, AnimatePresence } from 'framer-motion'
import { Menu, X, Phone, ChevronDown, Mail } from 'lucide-react'
import { Button } from '@/components/ui/button'

const navigation = [
  { name: 'About', href: '/about' },
  { 
    name: 'Services', 
    href: '/services',
    children: [
      { name: 'Metal Framing', href: '/services/metal-framing' },
      { name: 'Drywall', href: '/services/drywall' },
      { name: 'Commercial Painting', href: '/services/painting' },
      { name: 'Acoustical Ceilings', href: '/services/acoustical-ceilings' },
      { name: 'Wood Framing', href: '/services/wood-framing' },
      { name: 'View All Services', href: '/services' },
    ]
  },
  { name: 'Projects', href: '/projects' },
  { name: 'Team', href: '/team' },
  { name: 'Contact', href: '/contact' },
]

export function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false)
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null)

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20)
    }
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  return (
    <>
      {/* Top Bar - Hidden on scroll */}
      <div className={`hidden lg:block fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? '-translate-y-full opacity-0' : 'translate-y-0 opacity-100'
      }`}>
        <div className="bg-primary text-primary-foreground">
          <div className="container mx-auto px-4 lg:px-8">
            <div className="flex items-center justify-between h-10 text-sm">
              <div className="flex items-center gap-6">
                <a href="tel:+19735585226" className="flex items-center gap-2 hover:text-accent transition-colors">
                  <Phone className="w-3.5 h-3.5" />
                  <span>(973) 558-5226</span>
                </a>
                <a href="mailto:office@premiumcontractorllc.com" className="flex items-center gap-2 hover:text-accent transition-colors">
                  <Mail className="w-3.5 h-3.5" />
                  <span>office@premiumcontractorllc.com</span>
                </a>
              </div>
              <div className="flex items-center gap-4">
                <span className="text-primary-foreground/70">Serving NJ & NY Since 1988</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Navigation */}
      <motion.header
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        transition={{ duration: 0.5 }}
        className={`fixed left-0 right-0 z-50 transition-all duration-300 ${
          isScrolled 
            ? 'top-0 bg-white/98 backdrop-blur-md border-b border-border shadow-sm' 
            : 'top-10 bg-white/95 backdrop-blur-sm'
        }`}
      >
        <nav className="container mx-auto px-4 lg:px-8">
          <div className="flex items-center justify-between h-20">
            {/* Logo */}
            <Link href="/" className="flex items-center gap-3 group">
              <div className="relative w-12 h-14">
                <Image
                  src="/logo.png"
                  alt="Premium Contractors LLC"
                  fill
                  className="object-contain"
                  priority
                />
              </div>
              <div className="hidden sm:block">
                <span className="font-[family-name:var(--font-playfair)] font-semibold text-xl text-foreground group-hover:text-accent transition-colors">
                  Premium
                </span>
                <span className="block text-[10px] text-muted-foreground tracking-[0.25em] uppercase">
                  Contractors LLC
                </span>
              </div>
            </Link>

            {/* Desktop Navigation */}
            <div className="hidden lg:flex items-center gap-1">
              {navigation.map((item) => (
                <div 
                  key={item.name}
                  className="relative"
                  onMouseEnter={() => item.children && setActiveDropdown(item.name)}
                  onMouseLeave={() => setActiveDropdown(null)}
                >
                  <Link
                    href={item.href}
                    className="flex items-center gap-1 px-4 py-2 text-sm font-medium text-foreground/70 hover:text-foreground transition-colors animated-underline"
                  >
                    {item.name}
                    {item.children && <ChevronDown className="w-4 h-4" />}
                  </Link>
                  
                  {/* Dropdown */}
                  <AnimatePresence>
                    {item.children && activeDropdown === item.name && (
                      <motion.div
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: 10 }}
                        transition={{ duration: 0.2 }}
                        className="absolute top-full left-0 w-56 py-3 mt-1 bg-white border border-border rounded-xl shadow-xl"
                      >
                        {item.children.map((child, index) => (
                          <Link
                            key={child.name}
                            href={child.href}
                            className={`block px-5 py-2.5 text-sm text-foreground/70 hover:text-accent hover:bg-accent/5 transition-colors ${
                              index === item.children!.length - 1 ? 'border-t border-border mt-2 pt-3 font-medium text-accent' : ''
                            }`}
                          >
                            {child.name}
                          </Link>
                        ))}
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              ))}
            </div>

            {/* Desktop CTA */}
            <div className="hidden lg:flex items-center gap-4">
              <Button asChild className="bg-accent hover:bg-accent/90 text-accent-foreground font-semibold px-6">
                <Link href="/contact">Request Quote</Link>
              </Button>
            </div>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="lg:hidden p-2 text-foreground"
              aria-label="Toggle menu"
            >
              {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </nav>
      </motion.header>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, x: '100%' }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: '100%' }}
            transition={{ type: 'tween', duration: 0.3 }}
            className="fixed inset-0 z-40 lg:hidden"
          >
            <div 
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
              onClick={() => setIsMobileMenuOpen(false)}
            />
            <div className="absolute right-0 top-0 bottom-0 w-80 max-w-full bg-white">
              <div className="flex flex-col h-full pt-24 pb-8 px-6">
                <nav className="flex-1 space-y-1">
                  {navigation.map((item) => (
                    <div key={item.name}>
                      <Link
                        href={item.href}
                        onClick={() => setIsMobileMenuOpen(false)}
                        className="block py-3 text-lg font-medium text-foreground hover:text-accent transition-colors"
                      >
                        {item.name}
                      </Link>
                      {item.children && (
                        <div className="pl-4 space-y-1 mb-2">
                          {item.children.slice(0, -1).map((child) => (
                            <Link
                              key={child.name}
                              href={child.href}
                              onClick={() => setIsMobileMenuOpen(false)}
                              className="block py-2 text-sm text-muted-foreground hover:text-accent transition-colors"
                            >
                              {child.name}
                            </Link>
                          ))}
                        </div>
                      )}
                    </div>
                  ))}
                </nav>
                
                <div className="space-y-4 pt-6 border-t border-border">
                  <a 
                    href="tel:+19735585226" 
                    className="flex items-center gap-3 py-3 text-foreground"
                  >
                    <Phone className="w-5 h-5 text-accent" />
                    <span className="font-mono text-lg">(973) 558-5226</span>
                  </a>
                  <Button asChild className="w-full bg-accent hover:bg-accent/90 text-accent-foreground font-semibold">
                    <Link href="/contact" onClick={() => setIsMobileMenuOpen(false)}>
                      Request Quote
                    </Link>
                  </Button>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}
