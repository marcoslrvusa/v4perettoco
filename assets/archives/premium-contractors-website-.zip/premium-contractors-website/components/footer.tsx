import Link from 'next/link'
import Image from 'next/image'
import { Phone, Mail, MapPin, Linkedin, Clock, ArrowRight } from 'lucide-react'
import { Button } from '@/components/ui/button'

const footerLinks = {
  services: [
    { name: 'Metal Framing', href: '/services/metal-framing' },
    { name: 'Drywall', href: '/services/drywall' },
    { name: 'Commercial Painting', href: '/services/painting' },
    { name: 'Acoustical Ceilings', href: '/services/acoustical-ceilings' },
    { name: 'Wood Framing', href: '/services/wood-framing' },
    { name: 'All Services', href: '/services' },
  ],
  company: [
    { name: 'About Us', href: '/about' },
    { name: 'Our Team', href: '/team' },
    { name: 'Projects', href: '/projects' },
    { name: 'Safety', href: '/safety' },
    { name: 'Careers', href: '/careers' },
    { name: 'FAQ', href: '/faq' },
  ],
  industries: [
    { name: 'Hospitality', href: '/industries/hospitality' },
    { name: 'Multifamily', href: '/industries/multifamily' },
    { name: 'Commercial', href: '/industries/commercial' },
  ],
}

export function Footer() {
  return (
    <footer className="bg-primary text-primary-foreground">
      {/* CTA Banner */}
      <div className="bg-accent">
        <div className="container mx-auto px-4 lg:px-8 py-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div>
              <h3 className="font-[family-name:var(--font-playfair)] text-2xl md:text-3xl font-semibold text-white mb-2">
                Ready to Start Your Project?
              </h3>
              <p className="text-white/90">
                Get a free consultation and detailed quote within 24 hours.
              </p>
            </div>
            <Button asChild size="lg" className="bg-white text-accent hover:bg-white/90 font-semibold shrink-0">
              <Link href="/contact">
                Request Free Quote
                <ArrowRight className="ml-2 w-4 h-4" />
              </Link>
            </Button>
          </div>
        </div>
      </div>

      {/* Main Footer */}
      <div className="container mx-auto px-4 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-12">
          {/* Company Info */}
          <div className="lg:col-span-2">
            <Link href="/" className="flex items-center gap-3 mb-6">
              <div className="relative w-12 h-14 bg-white/10 rounded-lg p-2">
                <Image
                  src="/logo.png"
                  alt="Premium Contractors LLC"
                  fill
                  className="object-contain"
                />
              </div>
              <div>
                <span className="font-[family-name:var(--font-playfair)] font-semibold text-xl text-white">
                  Premium
                </span>
                <span className="block text-[10px] text-white/60 tracking-[0.25em] uppercase">
                  Contractors LLC
                </span>
              </div>
            </Link>
            <p className="text-white/70 mb-6 max-w-sm leading-relaxed">
              Commercial construction excellence since 1988. Trusted by Marriott, Hilton, 
              and industry leaders for precision craftsmanship and uncompromising quality.
            </p>
            <div className="space-y-3">
              <a 
                href="https://maps.google.com/?q=107+Vesey+St,+Newark,+NJ+07105"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-start gap-3 text-white/70 hover:text-accent transition-colors"
              >
                <MapPin className="w-5 h-5 mt-0.5 shrink-0" />
                <span>107 Vesey St, Newark, NJ 07105</span>
              </a>
              <a 
                href="tel:+19735585226" 
                className="flex items-center gap-3 text-white/70 hover:text-accent transition-colors"
              >
                <Phone className="w-5 h-5 shrink-0" />
                <span className="font-mono">(973) 558-5226</span>
              </a>
              <a 
                href="mailto:office@premiumcontractorllc.com" 
                className="flex items-center gap-3 text-white/70 hover:text-accent transition-colors"
              >
                <Mail className="w-5 h-5 shrink-0" />
                <span>office@premiumcontractorllc.com</span>
              </a>
              <div className="flex items-center gap-3 text-white/70">
                <Clock className="w-5 h-5 shrink-0" />
                <span>Mon - Fri: 7:00 AM - 5:00 PM</span>
              </div>
            </div>
          </div>

          {/* Services */}
          <div>
            <h3 className="font-semibold text-white mb-4 text-sm uppercase tracking-wider">
              Services
            </h3>
            <ul className="space-y-2.5">
              {footerLinks.services.map((link) => (
                <li key={link.name}>
                  <Link 
                    href={link.href}
                    className="text-white/60 hover:text-accent transition-colors text-sm"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Company */}
          <div>
            <h3 className="font-semibold text-white mb-4 text-sm uppercase tracking-wider">
              Company
            </h3>
            <ul className="space-y-2.5">
              {footerLinks.company.map((link) => (
                <li key={link.name}>
                  <Link 
                    href={link.href}
                    className="text-white/60 hover:text-accent transition-colors text-sm"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Industries */}
          <div>
            <h3 className="font-semibold text-white mb-4 text-sm uppercase tracking-wider">
              Industries
            </h3>
            <ul className="space-y-2.5">
              {footerLinks.industries.map((link) => (
                <li key={link.name}>
                  <Link 
                    href={link.href}
                    className="text-white/60 hover:text-accent transition-colors text-sm"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
            
            {/* Social */}
            <div className="mt-8">
              <h3 className="font-semibold text-white mb-4 text-sm uppercase tracking-wider">
                Connect
              </h3>
              <a
                href="https://www.linkedin.com/company/premium-contractorsllc"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 text-white/60 hover:text-accent transition-colors text-sm"
              >
                <Linkedin className="w-5 h-5" />
                <span>LinkedIn</span>
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-white/10">
        <div className="container mx-auto px-4 lg:px-8 py-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-sm text-white/50">
              &copy; {new Date().getFullYear()} Premium Contractors LLC. All rights reserved.
            </p>
            <div className="flex items-center gap-6 text-sm">
              <Link href="/privacy" className="text-white/50 hover:text-white transition-colors">
                Privacy Policy
              </Link>
              <Link href="/terms" className="text-white/50 hover:text-white transition-colors">
                Terms of Service
              </Link>
              <Link href="/llms.txt" className="text-white/50 hover:text-white transition-colors">
                llms.txt
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}
