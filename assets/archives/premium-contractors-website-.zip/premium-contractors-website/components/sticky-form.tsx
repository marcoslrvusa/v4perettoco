"use client"

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { X, CheckCircle2, ArrowRight, Phone, Shield, Clock, Award } from 'lucide-react'
import { Button } from '@/components/ui/button'

interface StickyFormProps {
  className?: string
}

export function StickyLeadForm({ className = '' }: StickyFormProps) {
  const [isMinimized, setIsMinimized] = useState(false)

  return (
    <div className={`hidden lg:block ${className}`}>
      <div className="sticky-form">
        <AnimatePresence mode="wait">
          {isMinimized ? (
            <motion.button
              key="minimized"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              onClick={() => setIsMinimized(false)}
              className="w-full bg-accent text-accent-foreground p-4 rounded-xl shadow-xl hover:bg-accent/90 transition-colors"
            >
              <div className="flex items-center justify-center gap-2">
                <Phone className="w-5 h-5" />
                <span className="font-semibold">Get Free Quote</span>
              </div>
            </motion.button>
          ) : (
            <motion.div
              key="expanded"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              className="bg-white border border-border rounded-2xl shadow-2xl overflow-hidden"
            >
              {/* Header */}
              <div className="bg-primary text-primary-foreground p-6 relative">
                <button
                  onClick={() => setIsMinimized(true)}
                  className="absolute top-4 right-4 p-1 hover:bg-white/10 rounded-full transition-colors"
                  aria-label="Minimize form"
                >
                  <X className="w-4 h-4" />
                </button>
                <div className="text-center">
                  <p className="text-sm text-primary-foreground/80 uppercase tracking-wider mb-1">
                    Free Consultation
                  </p>
                  <h3 className="font-[family-name:var(--font-playfair)] text-2xl font-semibold">
                    Request Your Quote
                  </h3>
                </div>
              </div>

              {/* Form - Go High Level Integration Ready */}
              <div className="p-6">
                {/* 
                  GO HIGH LEVEL INTEGRATION:
                  Replace this form with your GHL form embed code.
                  Example: <iframe src="https://api.leadconnectorhq.com/widget/form/YOUR_FORM_ID" ...></iframe>
                  Or use the GHL form submission endpoint with the form below.
                */}
                <form 
                  className="space-y-4"
                  action="https://services.leadconnectorhq.com/hooks/YOUR_WEBHOOK_ID"
                  method="POST"
                  data-ghl-form="true"
                >
                  <div>
                    <label htmlFor="sticky-name" className="block text-sm font-medium text-foreground mb-1.5">
                      Full Name *
                    </label>
                    <input
                      type="text"
                      id="sticky-name"
                      name="full_name"
                      required
                      className="w-full px-4 py-3 bg-secondary border border-border rounded-lg text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent focus:border-transparent transition-all text-sm"
                      placeholder="John Smith"
                    />
                  </div>

                  <div>
                    <label htmlFor="sticky-email" className="block text-sm font-medium text-foreground mb-1.5">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      id="sticky-email"
                      name="email"
                      required
                      className="w-full px-4 py-3 bg-secondary border border-border rounded-lg text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent focus:border-transparent transition-all text-sm"
                      placeholder="john@company.com"
                    />
                  </div>

                  <div>
                    <label htmlFor="sticky-phone" className="block text-sm font-medium text-foreground mb-1.5">
                      Phone Number *
                    </label>
                    <input
                      type="tel"
                      id="sticky-phone"
                      name="phone"
                      required
                      className="w-full px-4 py-3 bg-secondary border border-border rounded-lg text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent focus:border-transparent transition-all text-sm"
                      placeholder="(555) 000-0000"
                    />
                  </div>

                  <div>
                    <label htmlFor="sticky-project" className="block text-sm font-medium text-foreground mb-1.5">
                      Project Type *
                    </label>
                    <select
                      id="sticky-project"
                      name="project_type"
                      required
                      className="w-full px-4 py-3 bg-secondary border border-border rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-accent focus:border-transparent transition-all text-sm"
                    >
                      <option value="">Select project type</option>
                      <option value="Hotel / Hospitality">Hotel / Hospitality</option>
                      <option value="Restaurant / Food Service">Restaurant / Food Service</option>
                      <option value="Commercial Office">Commercial Office</option>
                      <option value="Multifamily Residential">Multifamily Residential</option>
                      <option value="Retail Space">Retail Space</option>
                      <option value="Healthcare Facility">Healthcare Facility</option>
                      <option value="Other">Other</option>
                    </select>
                  </div>

                  <div>
                    <label htmlFor="sticky-message" className="block text-sm font-medium text-foreground mb-1.5">
                      Project Details
                    </label>
                    <textarea
                      id="sticky-message"
                      name="message"
                      rows={3}
                      className="w-full px-4 py-3 bg-secondary border border-border rounded-lg text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent focus:border-transparent transition-all text-sm resize-none"
                      placeholder="Brief project description..."
                    />
                  </div>

                  {/* Hidden fields for tracking */}
                  <input type="hidden" name="source" value="website_sticky_form" />
                  <input type="hidden" name="page_url" value="" id="page-url-field" />

                  <Button 
                    type="submit" 
                    size="lg" 
                    className="w-full bg-accent hover:bg-accent/90 text-accent-foreground font-semibold h-12"
                  >
                    Get My Free Quote
                    <ArrowRight className="ml-2 w-4 h-4" />
                  </Button>
                </form>

                {/* Trust Indicators */}
                <div className="mt-6 pt-6 border-t border-border">
                  <div className="grid grid-cols-2 gap-3">
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <Clock className="w-3.5 h-3.5 text-accent" />
                      <span>24hr Response</span>
                    </div>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <Shield className="w-3.5 h-3.5 text-accent" />
                      <span>Licensed & Insured</span>
                    </div>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <Award className="w-3.5 h-3.5 text-accent" />
                      <span>37+ Years Exp.</span>
                    </div>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <CheckCircle2 className="w-3.5 h-3.5 text-accent" />
                      <span>Free Estimates</span>
                    </div>
                  </div>
                </div>

                {/* Urgency/Social Proof */}
                <div className="mt-4 p-3 bg-accent/5 rounded-lg border border-accent/20">
                  <p className="text-xs text-center text-foreground">
                    <span className="font-semibold text-accent">127+ projects</span> completed for Marriott, Hilton & more
                  </p>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  )
}

export function MobileFloatingCTA() {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <>
      {/* Mobile Floating Button */}
      <div className="fixed bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-white via-white to-transparent lg:hidden z-50">
        <Button 
          onClick={() => setIsOpen(true)}
          size="lg" 
          className="w-full bg-accent hover:bg-accent/90 text-accent-foreground font-semibold h-14 shadow-xl"
        >
          <Phone className="mr-2 w-5 h-5" />
          Get Free Quote
        </Button>
      </div>

      {/* Mobile Form Modal */}
      <AnimatePresence>
        {isOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsOpen(false)}
              className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 lg:hidden"
            />
            <motion.div
              initial={{ opacity: 0, y: '100%' }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 300 }}
              className="fixed inset-x-0 bottom-0 bg-white rounded-t-3xl z-50 lg:hidden max-h-[90vh] overflow-y-auto"
            >
              {/* Handle */}
              <div className="flex justify-center pt-3">
                <div className="w-10 h-1 bg-border rounded-full" />
              </div>

              {/* Header */}
              <div className="flex items-center justify-between p-4 border-b border-border">
                <div>
                  <p className="text-xs text-muted-foreground uppercase tracking-wider">Free Consultation</p>
                  <h3 className="font-[family-name:var(--font-playfair)] text-xl font-semibold text-foreground">
                    Request Your Quote
                  </h3>
                </div>
                <button
                  onClick={() => setIsOpen(false)}
                  className="p-2 hover:bg-muted rounded-full transition-colors"
                >
                  <X className="w-5 h-5 text-muted-foreground" />
                </button>
              </div>

              {/* Form */}
              <div className="p-4 pb-8">
                <form 
                  className="space-y-4"
                  action="https://services.leadconnectorhq.com/hooks/YOUR_WEBHOOK_ID"
                  method="POST"
                >
                  <div>
                    <input
                      type="text"
                      name="full_name"
                      required
                      className="w-full px-4 py-4 bg-secondary border border-border rounded-xl text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent focus:border-transparent transition-all"
                      placeholder="Full Name *"
                    />
                  </div>

                  <div>
                    <input
                      type="email"
                      name="email"
                      required
                      className="w-full px-4 py-4 bg-secondary border border-border rounded-xl text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent focus:border-transparent transition-all"
                      placeholder="Email Address *"
                    />
                  </div>

                  <div>
                    <input
                      type="tel"
                      name="phone"
                      required
                      className="w-full px-4 py-4 bg-secondary border border-border rounded-xl text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent focus:border-transparent transition-all"
                      placeholder="Phone Number *"
                    />
                  </div>

                  <div>
                    <select
                      name="project_type"
                      required
                      className="w-full px-4 py-4 bg-secondary border border-border rounded-xl text-foreground focus:outline-none focus:ring-2 focus:ring-accent focus:border-transparent transition-all"
                    >
                      <option value="">Project Type *</option>
                      <option value="Hotel / Hospitality">Hotel / Hospitality</option>
                      <option value="Restaurant / Food Service">Restaurant / Food Service</option>
                      <option value="Commercial Office">Commercial Office</option>
                      <option value="Multifamily Residential">Multifamily Residential</option>
                      <option value="Retail Space">Retail Space</option>
                      <option value="Other">Other</option>
                    </select>
                  </div>

                  <Button 
                    type="submit" 
                    size="lg" 
                    className="w-full bg-accent hover:bg-accent/90 text-accent-foreground font-semibold h-14"
                  >
                    Get My Free Quote
                    <ArrowRight className="ml-2 w-5 h-5" />
                  </Button>
                </form>

                {/* Trust */}
                <div className="flex flex-wrap items-center justify-center gap-4 mt-6 pt-6 border-t border-border">
                  <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                    <CheckCircle2 className="w-3.5 h-3.5 text-accent" />
                    <span>Free Estimates</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                    <Shield className="w-3.5 h-3.5 text-accent" />
                    <span>Licensed & Insured</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                    <Award className="w-3.5 h-3.5 text-accent" />
                    <span>37+ Years</span>
                  </div>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  )
}
