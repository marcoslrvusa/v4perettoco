export const team = [
  {
    name: 'Diniz Teixeira',
    role: 'President & Founder',
    bio: 'With over 37 years of experience in commercial construction, Diniz founded Premium Contractors in 1988. His vision and leadership have built the company into a trusted partner for major hotel brands and commercial developers.',
    image: '/team/diniz.jpg',
  },
  {
    name: 'Emerson Rodrigues',
    role: 'Finance Director',
    bio: 'Emerson oversees all financial operations, ensuring Premium Contractors maintains strong fiscal health while delivering competitive pricing to clients.',
    image: '/team/emerson.jpg',
  },
  {
    name: 'Brenda Souza',
    role: 'Office Manager',
    bio: 'Brenda manages daily operations and administrative functions, serving as the central point of contact for client communications.',
    image: '/team/brenda.jpg',
  },
  {
    name: 'Robert Firme',
    role: 'Project Manager',
    bio: 'Robert brings extensive field experience to project management, coordinating crews and ensuring projects meet quality standards and deadlines.',
    image: '/team/robert.jpg',
  },
  {
    name: 'Italo Bacelar',
    role: 'Project Assistant',
    bio: 'Italo supports project management operations, assisting with scheduling, documentation, and field coordination.',
    image: '/team/italo.jpg',
  },
]

export const companyValues = [
  {
    title: 'Quality',
    description: 'We deliver exceptional craftsmanship on every project, meeting and exceeding industry standards.',
  },
  {
    title: 'Innovation',
    description: 'We embrace new techniques and technologies to improve efficiency and results.',
  },
  {
    title: 'Integrity',
    description: 'We operate with honesty and transparency in all business relationships.',
  },
  {
    title: 'Collaboration',
    description: 'We work closely with clients, architects, and trades to achieve shared goals.',
  },
]

export const companyStats = {
  yearsInBusiness: 37,
  projectsCompleted: 250,
  clientPartners: 50,
  serviceAreas: 'NJ + NY',
}

export const testimonials = [
  {
    quote: "Premium Contractors is an incredible business partner. They are professional, their crews are skilled and talented, and they deliver on time. Their attention to customer service, detail, and understanding project timelines is of highest importance. Highly recommend.",
    author: 'Jason Honigfeld',
    title: 'COO/CFO',
    company: 'The Briad Group',
  },
  {
    quote: "Working with Premium Contractors has been a consistently positive experience. Their team understands the demands of hotel construction and delivers quality work that meets brand standards.",
    author: 'Project Manager',
    title: 'Development Team',
    company: 'Marriott International',
  },
]

export type TeamMember = typeof team[number]
