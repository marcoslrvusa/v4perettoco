export const projects = [
  {
    slug: 'the-edge-multifamily',
    name: 'The Edge Multi-Family Residential',
    location: 'Elizabeth, NJ',
    type: 'Multifamily',
    client: 'Private Developer',
    scope: ['Metal Framing', 'Drywall', 'Painting', 'Acoustical Ceilings'],
    description: 'A premier 50-unit multifamily residential development featuring modern amenities and high-end finishes. Premium Contractors delivered complete interior construction including metal framing, drywall, and finish work.',
    highlights: [
      '50 residential units',
      'Modern construction techniques',
      'High-end interior finishes',
      'On-time delivery'
    ],
    featured: true,
    image: '/projects/the-edge.jpg',
  },
  {
    slug: 'signature-flight-support',
    name: 'Signature Flight Support',
    location: 'Atlantic City Airport, NJ',
    type: 'Commercial',
    client: 'Signature Aviation',
    scope: ['Painting', 'Acoustical Ceilings', 'Metal Framing', 'Drywall'],
    description: 'Complete renovation of the Signature Flight Support facility at Atlantic City International Airport. This project required coordination with active airport operations while delivering premium finishes.',
    highlights: [
      'Airport facility renovation',
      'Active operations coordination',
      'Premium finishes',
      'Safety compliance'
    ],
    featured: true,
    image: '/projects/signature-flight.jpg',
  },
  {
    slug: 'marriott-fairfield-inn',
    name: 'Marriott Fairfield Inn',
    location: 'Newark, NJ',
    type: 'Hospitality',
    client: 'Marriott International',
    scope: ['Metal Framing', 'Drywall', 'Painting', 'Flooring', 'Acoustical Ceilings'],
    description: 'Full interior construction for a new Marriott Fairfield Inn hotel. Premium Contractors delivered all interior trades meeting Marriott brand standards.',
    highlights: [
      'Brand standard compliance',
      'Multi-trade coordination',
      'Quality finishes',
      'Tight timeline delivery'
    ],
    featured: true,
    image: '/projects/marriott-fairfield.jpg',
  },
  {
    slug: 'hilton-garden-inn',
    name: 'Hilton Garden Inn',
    location: 'Jersey City, NJ',
    type: 'Hospitality',
    client: 'Hilton Hotels',
    scope: ['Metal Framing', 'Drywall', 'Painting', 'Wallcovering', 'Doors'],
    description: 'Complete interior package for a new Hilton Garden Inn property. Our team coordinated multiple trades to deliver on schedule.',
    highlights: [
      'Full interior package',
      'Hilton brand standards',
      'Complex coordination',
      'Quality execution'
    ],
    featured: false,
    image: '/projects/hilton-garden.jpg',
  },
  {
    slug: 'wendys-renovation',
    name: "Wendy's Restaurant Renovations",
    location: 'Multiple Locations, NJ/NY',
    type: 'Restaurant',
    client: "Wendy's / The Briad Group",
    scope: ['Metal Framing', 'Drywall', 'Painting', 'Flooring', 'Finish Trimming'],
    description: "Multiple Wendy's restaurant renovations across New Jersey and New York. Premium Contractors delivered consistent quality across all locations.",
    highlights: [
      'Multi-location program',
      'Brand consistency',
      'Fast turnaround',
      'Operational coordination'
    ],
    featured: false,
    image: '/projects/wendys.jpg',
  },
  {
    slug: 'office-tower-newark',
    name: 'Commercial Office Tower',
    location: 'Newark, NJ',
    type: 'Commercial',
    client: 'Private Investment Group',
    scope: ['Metal Framing', 'Drywall', 'Acoustical Ceilings', 'Painting', 'Doors'],
    description: 'Major tenant improvement project in a Class A office tower in downtown Newark. Premium Contractors delivered 50,000 SF of high-end office space.',
    highlights: [
      '50,000 SF renovation',
      'Class A standards',
      'Complex logistics',
      'Premium finishes'
    ],
    featured: false,
    image: '/projects/office-tower.jpg',
  },
]

export const clients = [
  { name: 'Marriott', logo: '/clients/marriott.png' },
  { name: 'Hilton', logo: '/clients/hilton.png' },
  { name: "Wendy's", logo: '/clients/wendys.png' },
  { name: 'The Briad Group', logo: '/clients/briad.png' },
  { name: 'Signature Aviation', logo: '/clients/signature.png' },
]

export type Project = typeof projects[number]
