export const services = [
  {
    slug: 'metal-framing',
    name: 'Metal Framing',
    shortDescription: 'Light gauge steel framing for commercial buildings with precision engineering.',
    description: 'Premium Contractors specializes in light gauge steel framing for commercial construction. Our expert team delivers precision-engineered metal framing solutions for hotels, restaurants, multifamily buildings, and commercial spaces throughout New Jersey and New York.',
    features: [
      'Light gauge steel framing',
      'Load-bearing wall systems',
      'Non-load bearing partitions',
      'Curtain wall framing',
      'Structural steel connections',
      'Fire-rated assemblies'
    ],
    icon: 'frame',
  },
  {
    slug: 'drywall',
    name: 'Drywall & Finishing',
    shortDescription: 'Expert drywall installation, taping, and smooth finishes for any commercial project.',
    description: 'Our drywall services include complete installation, taping, spackling, and finishing to the highest standards. We handle projects of all sizes, from hotel renovations to new commercial construction.',
    features: [
      'Drywall installation',
      'Tape and spackle',
      'Level 5 finishes',
      'Fire-rated assemblies',
      'Moisture-resistant board',
      'Sound attenuation systems'
    ],
    icon: 'layers',
  },
  {
    slug: 'painting',
    name: 'Commercial Painting',
    shortDescription: 'Interior and exterior painting services with premium materials and expert application.',
    description: 'Premium Contractors delivers exceptional commercial painting services for hotels, restaurants, and commercial buildings. Our crews are trained in the latest techniques and use premium materials for lasting results.',
    features: [
      'Interior painting',
      'Exterior painting',
      'Specialty coatings',
      'Epoxy flooring',
      'Staining and lacquering',
      'Color consultation'
    ],
    icon: 'paintbrush',
  },
  {
    slug: 'acoustical-ceilings',
    name: 'Acoustical Ceilings',
    shortDescription: 'Suspended ceiling systems designed for optimal sound control and aesthetics.',
    description: 'We install complete acoustical ceiling systems that combine functionality with design. Our suspended ceiling solutions improve acoustics while creating clean, professional environments.',
    features: [
      'Suspended ceiling systems',
      'Acoustic panel installation',
      'Grid systems',
      'Sound attenuation',
      'Fire-rated ceilings',
      'Custom designs'
    ],
    icon: 'grid3x3',
  },
  {
    slug: 'wood-framing',
    name: 'Wood Framing',
    shortDescription: 'Traditional wood framing expertise for structural and non-structural applications.',
    description: 'Our wood framing services provide traditional construction solutions with modern precision. We handle everything from structural framing to detailed millwork.',
    features: [
      'Structural wood framing',
      'Floor systems',
      'Roof framing',
      'Wall systems',
      'Blocking and backing',
      'Custom millwork framing'
    ],
    icon: 'box',
  },
  {
    slug: 'insulation',
    name: 'Insulation',
    shortDescription: 'Thermal and acoustic insulation solutions for energy efficiency and comfort.',
    description: 'Premium Contractors installs high-performance insulation systems that improve energy efficiency and acoustic comfort. We work with all major insulation types to meet project specifications.',
    features: [
      'Batt insulation',
      'Blown-in insulation',
      'Spray foam',
      'Rigid board',
      'Sound insulation',
      'Fire-stopping'
    ],
    icon: 'thermometer',
  },
  {
    slug: 'wallcovering',
    name: 'Wallcovering',
    shortDescription: 'Commercial wallpaper and specialty wall finish installation.',
    description: 'Our wallcovering specialists install commercial-grade wallpaper and specialty finishes that transform interior spaces. We work with hotels and commercial clients to deliver stunning results.',
    features: [
      'Commercial wallpaper',
      'Vinyl wallcovering',
      'Specialty finishes',
      'Acoustic wallcovering',
      'Custom installations',
      'Surface preparation'
    ],
    icon: 'wallpaper',
  },
  {
    slug: 'flooring',
    name: 'Ceramic/LVT/Carpet Tile',
    shortDescription: 'Complete flooring installation including ceramic, LVT, and carpet tile.',
    description: 'Premium Contractors provides comprehensive flooring solutions for commercial projects. From ceramic tile to luxury vinyl and carpet tile, we deliver beautiful, durable floors.',
    features: [
      'Ceramic tile',
      'Porcelain tile',
      'Luxury vinyl tile (LVT)',
      'Carpet tile',
      'Floor preparation',
      'Transitions and trim'
    ],
    icon: 'square',
  },
  {
    slug: 'kitchen-cabinets',
    name: 'Kitchen Cabinets',
    shortDescription: 'Commercial cabinetry installation for restaurants and hospitality.',
    description: 'We install commercial kitchen cabinets and millwork for restaurants, hotels, and commercial kitchens. Our installers ensure precise fit and professional finishes.',
    features: [
      'Cabinet installation',
      'Commercial millwork',
      'Custom fitting',
      'Hardware installation',
      'Countertop coordination',
      'Final adjustments'
    ],
    icon: 'cabinet',
  },
  {
    slug: 'doors',
    name: 'Door Installation',
    shortDescription: 'Commercial door installation including frames, hardware, and fire-rated assemblies.',
    description: 'Premium Contractors handles all aspects of commercial door installation, from hollow metal frames to finish hardware. We specialize in fire-rated and security door systems.',
    features: [
      'Hollow metal frames',
      'Wood doors',
      'Fire-rated doors',
      'Hardware installation',
      'ADA compliance',
      'Security doors'
    ],
    icon: 'doorOpen',
  },
  {
    slug: 'finish-trimming',
    name: 'Finish Trimming',
    shortDescription: 'Detailed finish carpentry including baseboards, crown molding, and casings.',
    description: 'Our finish carpentry team delivers the detailed trimwork that completes any commercial project. From baseboards to crown molding, we ensure every detail is perfect.',
    features: [
      'Baseboards',
      'Crown molding',
      'Door casings',
      'Window trim',
      'Chair rails',
      'Custom millwork'
    ],
    icon: 'ruler',
  },
  {
    slug: 'metal-ceilings',
    name: 'Metal Ceilings',
    shortDescription: 'Architectural metal ceiling systems for premium commercial spaces.',
    description: 'We install architectural metal ceiling systems that create stunning visual impact. Our metal ceiling solutions are perfect for lobbies, restaurants, and high-end commercial spaces.',
    features: [
      'Linear metal ceilings',
      'Metal panel systems',
      'Perforated panels',
      'Custom designs',
      'Integrated lighting',
      'Specialty finishes'
    ],
    icon: 'sparkles',
  },
  {
    slug: 'asphalt-repairs',
    name: 'Asphalt Repairs',
    shortDescription: 'Parking lot and pavement repair and maintenance services.',
    description: 'Premium Contractors provides asphalt repair services for commercial properties. We handle everything from pothole repairs to complete resurfacing projects.',
    features: [
      'Pothole repair',
      'Crack sealing',
      'Sealcoating',
      'Striping',
      'Patching',
      'Surface repair'
    ],
    icon: 'road',
  },
  {
    slug: 'stripping',
    name: 'Stripping Services',
    shortDescription: 'Paint and wallcovering removal for renovation projects.',
    description: 'Our stripping services prepare surfaces for new finishes. We safely remove old paint, wallpaper, and coatings from walls, ceilings, and other surfaces.',
    features: [
      'Paint removal',
      'Wallpaper stripping',
      'Surface preparation',
      'Chemical stripping',
      'Mechanical removal',
      'Lead paint compliance'
    ],
    icon: 'eraser',
  },
  {
    slug: 'cleaning',
    name: 'Post-Construction Cleaning',
    shortDescription: 'Professional cleaning services to prepare spaces for occupancy.',
    description: 'We provide thorough post-construction cleaning to prepare commercial spaces for occupancy. Our cleaning crews ensure every surface is spotless and ready for use.',
    features: [
      'Debris removal',
      'Dust cleaning',
      'Window cleaning',
      'Floor cleaning',
      'Final touch-up',
      'Punch list cleaning'
    ],
    icon: 'sparkle',
  },
]

export type Service = typeof services[number]
