import { NextResponse } from 'next/server'

const llmsTxt = `# Premium Contractors LLC

> Commercial construction company serving New Jersey and New York since 1988.

## Company
- Name: Premium Contractors LLC
- Founded: 1988
- Headquarters: 107 Vesey St, Newark, NJ 07105
- Phone: 973-558-5226
- Email: office@premiumcontractorllc.com
- Service Area: New Jersey, New York
- President: Diniz Teixeira

## Services
- Metal Framing: Light gauge steel framing for commercial buildings
- Drywall & Finishing: Taping, spackling, and smooth finishes
- Commercial Painting: Interior and exterior painting
- Acoustical Ceilings: Suspended ceiling systems
- Wood Framing: Structural wood framing
- Insulation: Thermal and acoustic insulation
- Wallcovering: Commercial wallpaper installation
- Ceramic/LVT/Carpet Tile: Flooring installation
- Kitchen Cabinets: Commercial cabinetry installation
- Doors: Commercial door installation
- Finish Trimming: Baseboards, crown molding, casing
- Metal Ceilings: Architectural metal ceiling systems
- Asphalt Repairs: Parking lot and pavement repair
- Stripping Services: Paint and wallcovering removal
- Cleaning: Post-construction cleaning

## Key Clients
- Marriott Hotels
- Hilton Hotels
- Wendy's
- The Briad Group

## Notable Projects
- The Edge Multi-Family Residential (Elizabeth, NJ) — 50 rooms, metal framing
- Signature Flight Support (Atlantic City Airport, NJ) — painting, acoustical ceiling, framing
- Marriott Fairfield Inn (Newark, NJ) — full interior construction
- Hilton Garden Inn (Jersey City, NJ) — complete interior package

## Industries Served
- Hospitality: Hotels, resorts, conference centers
- Restaurants: Fast casual, full service, franchise locations
- Multifamily: Apartments, condos, senior living
- Commercial: Offices, retail, medical facilities

## Company Values
- Quality: Exceptional craftsmanship on every project
- Innovation: Embracing new techniques and technologies
- Integrity: Honest and transparent business relationships
- Collaboration: Working closely with clients and partners

## Links
- Website: https://www.premiumcontractorllc.com
- LinkedIn: https://www.linkedin.com/company/premium-contractorsllc
- Contact: https://www.premiumcontractorllc.com/contact
- Services: https://www.premiumcontractorllc.com/services
- Projects: https://www.premiumcontractorllc.com/projects
`

export async function GET() {
  return new NextResponse(llmsTxt, {
    headers: {
      'Content-Type': 'text/plain; charset=utf-8',
    },
  })
}
