import { Metadata } from 'next'
import Link from 'next/link'
import { ArrowRight, Shield, HardHat, AlertTriangle, CheckCircle2, Award, Users } from 'lucide-react'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { SectionHeading, FadeIn, StaggerContainer } from '@/components/animations'
import { Button } from '@/components/ui/button'

export const metadata: Metadata = {
  title: 'Safety | Our Commitment to Workplace Safety',
  description: 'Learn about Premium Contractors LLC commitment to workplace safety. We prioritize the well-being of our workers and maintain strict safety protocols on every job site.',
}

const safetyPrinciples = [
  {
    icon: HardHat,
    title: 'Safety First Culture',
    description: 'Safety is not just a policy—it\'s our culture. Every team member is empowered to stop work if they see unsafe conditions.'
  },
  {
    icon: Users,
    title: 'Continuous Training',
    description: 'All employees receive ongoing safety training, including OSHA certification and job-specific safety protocols.'
  },
  {
    icon: AlertTriangle,
    title: 'Hazard Prevention',
    description: 'We proactively identify and mitigate potential hazards before work begins through comprehensive job site analysis.'
  },
  {
    icon: Shield,
    title: 'Compliance',
    description: 'We maintain strict compliance with all OSHA regulations, state requirements, and industry best practices.'
  },
]

const certifications = [
  'OSHA 10 & OSHA 30 Certified',
  'Workers\' Compensation Insurance',
  'General Liability Insurance',
  'State Licensed Contractor',
  'Safety Management Program',
  'Regular Safety Audits'
]

export default function SafetyPage() {
  return (
    <>
      <Navbar />
      <main className="pb-16 lg:pb-0">
        {/* Hero */}
        <section className="pt-32 pb-16 lg:pb-24 relative noise-bg">
          <div className="absolute inset-0 bg-gradient-to-br from-background via-primary/50 to-background" />
          <div className="absolute inset-0 grid-pattern opacity-30" />
          
          <div className="container mx-auto px-4 lg:px-8 relative z-10">
            <FadeIn className="max-w-3xl">
              <span className="inline-block px-4 py-1.5 text-xs font-mono uppercase tracking-wider bg-accent/10 text-accent rounded-full mb-4">
                Safety
              </span>
              <h1 className="font-[family-name:var(--font-inter-tight)] text-4xl md:text-5xl lg:text-6xl font-black text-foreground mb-6">
                Safety Is Our Foundation
              </h1>
              <p className="text-xl text-muted-foreground">
                At Premium Contractors, we believe that no project is successful unless everyone goes home safely. Our commitment to workplace safety is unwavering.
              </p>
            </FadeIn>
          </div>
        </section>

        {/* Safety Principles */}
        <section className="py-16 lg:py-24">
          <div className="container mx-auto px-4 lg:px-8">
            <SectionHeading
              badge="Our Approach"
              title="Safety Principles"
              description="The core principles that guide our safety program."
            />
            <StaggerContainer className="grid md:grid-cols-2 gap-6 mt-12">
              {safetyPrinciples.map((principle) => {
                const Icon = principle.icon
                return (
                  <FadeIn key={principle.title}>
                    <div className="p-6 bg-card border border-border rounded-xl h-full">
                      <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center mb-4">
                        <Icon className="w-6 h-6 text-accent" />
                      </div>
                      <h3 className="font-[family-name:var(--font-inter-tight)] text-xl font-bold text-foreground mb-2">
                        {principle.title}
                      </h3>
                      <p className="text-muted-foreground">
                        {principle.description}
                      </p>
                    </div>
                  </FadeIn>
                )
              })}
            </StaggerContainer>
          </div>
        </section>

        {/* Certifications */}
        <section className="py-16 lg:py-24 bg-card/50 border-y border-border">
          <div className="container mx-auto px-4 lg:px-8">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <FadeIn>
                <Award className="w-12 h-12 text-accent mb-6" />
                <h2 className="font-[family-name:var(--font-inter-tight)] text-3xl font-bold text-foreground mb-4">
                  Certifications & Compliance
                </h2>
                <p className="text-muted-foreground mb-6">
                  Premium Contractors maintains all required certifications and insurance coverage to ensure we can safely and legally perform work on your project.
                </p>
              </FadeIn>
              <FadeIn delay={0.2}>
                <ul className="grid sm:grid-cols-2 gap-4">
                  {certifications.map((cert) => (
                    <li key={cert} className="flex items-center gap-3">
                      <CheckCircle2 className="w-5 h-5 text-accent shrink-0" />
                      <span className="text-foreground">{cert}</span>
                    </li>
                  ))}
                </ul>
              </FadeIn>
            </div>
          </div>
        </section>

        {/* Safety Commitment */}
        <section className="py-16 lg:py-24">
          <div className="container mx-auto px-4 lg:px-8">
            <FadeIn className="max-w-3xl mx-auto text-center">
              <h2 className="font-[family-name:var(--font-inter-tight)] text-3xl md:text-4xl font-bold text-foreground mb-6">
                Our Commitment
              </h2>
              <p className="text-xl text-muted-foreground mb-8 text-pretty">
                &ldquo;Every worker deserves to return home safely at the end of each day. This belief drives every decision we make on the job site.&rdquo;
              </p>
              <p className="text-muted-foreground">
                — Diniz Teixeira, President & Founder
              </p>
            </FadeIn>
          </div>
        </section>

        {/* CTA */}
        <section className="py-16 lg:py-24 bg-card border-t border-border">
          <div className="container mx-auto px-4 lg:px-8 text-center">
            <FadeIn>
              <h2 className="font-[family-name:var(--font-inter-tight)] text-3xl md:text-4xl font-bold text-foreground mb-4">
                Questions About Our Safety Program?
              </h2>
              <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
                Contact us to learn more about our safety protocols and how we protect workers on every job site.
              </p>
              <Button asChild size="lg" className="bg-accent hover:bg-accent/90 text-accent-foreground font-semibold">
                <Link href="/contact">
                  Contact Us
                  <ArrowRight className="ml-2 w-4 h-4" />
                </Link>
              </Button>
            </FadeIn>
          </div>
        </section>
      </main>
      <Footer />
    </>
  )
}
