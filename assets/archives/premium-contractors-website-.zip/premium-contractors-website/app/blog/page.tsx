import { Metadata } from 'next'
import Link from 'next/link'
import { ArrowRight, Calendar, Clock, User } from 'lucide-react'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { FadeIn, StaggerContainer } from '@/components/animations'
import { Button } from '@/components/ui/button'

export const metadata: Metadata = {
  title: 'Blog | Construction Industry Insights',
  description: 'Read the latest insights, tips, and news about commercial construction from Premium Contractors LLC. Expert advice on hotel construction, drywall, metal framing, and more.',
}

const blogPosts = [
  {
    slug: 'hotel-construction-trends-2024',
    title: 'Hotel Construction Trends: What to Expect',
    excerpt: 'Discover the latest trends shaping hotel construction, from sustainable materials to smart building technology.',
    author: 'Premium Contractors',
    date: '2024-01-15',
    readTime: '5 min read',
    category: 'Industry Trends'
  },
  {
    slug: 'choosing-right-contractor',
    title: 'How to Choose the Right Commercial Contractor',
    excerpt: 'Key factors to consider when selecting a general contractor for your commercial construction project.',
    author: 'Premium Contractors',
    date: '2024-01-08',
    readTime: '4 min read',
    category: 'Tips & Advice'
  },
  {
    slug: 'metal-framing-vs-wood-framing',
    title: 'Metal Framing vs. Wood Framing: Which Is Right for Your Project?',
    excerpt: 'Compare the benefits and considerations of metal and wood framing for commercial construction.',
    author: 'Premium Contractors',
    date: '2023-12-20',
    readTime: '6 min read',
    category: 'Technical'
  },
  {
    slug: 'importance-of-acoustical-ceilings',
    title: 'The Importance of Acoustical Ceilings in Commercial Spaces',
    excerpt: 'Learn how acoustical ceiling systems improve comfort and productivity in offices, hotels, and retail spaces.',
    author: 'Premium Contractors',
    date: '2023-12-10',
    readTime: '4 min read',
    category: 'Technical'
  },
  {
    slug: 'commercial-painting-best-practices',
    title: 'Commercial Painting Best Practices',
    excerpt: 'Tips for achieving professional results in commercial painting projects, from preparation to final coat.',
    author: 'Premium Contractors',
    date: '2023-11-28',
    readTime: '5 min read',
    category: 'Tips & Advice'
  },
  {
    slug: 'sustainable-construction-practices',
    title: 'Sustainable Construction Practices for Commercial Buildings',
    excerpt: 'How modern construction companies are reducing environmental impact while maintaining quality.',
    author: 'Premium Contractors',
    date: '2023-11-15',
    readTime: '7 min read',
    category: 'Industry Trends'
  },
]

function formatDate(dateString: string) {
  const date = new Date(dateString)
  return date.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })
}

export default function BlogPage() {
  return (
    <>
      <Navbar />
      <main className="pb-16 lg:pb-0">
        {/* Hero */}
        <section className="pt-32 pb-16 lg:pb-24 relative noise-bg">
          <div className="absolute inset-0 bg-gradient-to-br from-background via-primary/50 to-background" />
          <div className="absolute inset-0 grid-pattern opacity-30" />
          
          <div className="container mx-auto px-4 lg:px-8 relative z-10">
            <FadeIn className="max-w-3xl">
              <span className="inline-block px-4 py-1.5 text-xs font-mono uppercase tracking-wider bg-accent/10 text-accent rounded-full mb-4">
                Blog
              </span>
              <h1 className="font-[family-name:var(--font-inter-tight)] text-4xl md:text-5xl lg:text-6xl font-black text-foreground mb-6">
                Construction Insights
              </h1>
              <p className="text-xl text-muted-foreground">
                Expert insights, industry trends, and practical tips from 37+ years of commercial construction experience.
              </p>
            </FadeIn>
          </div>
        </section>

        {/* Blog Grid */}
        <section className="py-16 lg:py-24">
          <div className="container mx-auto px-4 lg:px-8">
            <StaggerContainer className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {blogPosts.map((post, index) => (
                <FadeIn key={post.slug} delay={index * 0.1}>
                  <article className="group bg-card border border-border rounded-xl overflow-hidden hover:border-accent/50 transition-all h-full flex flex-col">
                    <div className="aspect-video bg-muted relative">
                      <div className="absolute top-4 left-4">
                        <span className="px-3 py-1 text-xs font-mono bg-accent text-accent-foreground rounded-full">
                          {post.category}
                        </span>
                      </div>
                    </div>
                    <div className="p-6 flex-1 flex flex-col">
                      <div className="flex items-center gap-4 text-xs text-muted-foreground mb-3">
                        <span className="flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          {formatDate(post.date)}
                        </span>
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {post.readTime}
                        </span>
                      </div>
                      <h2 className="font-[family-name:var(--font-inter-tight)] text-xl font-bold text-foreground mb-2 group-hover:text-accent transition-colors">
                        {post.title}
                      </h2>
                      <p className="text-muted-foreground text-sm mb-4 flex-1">
                        {post.excerpt}
                      </p>
                      <div className="flex items-center justify-between pt-4 border-t border-border">
                        <span className="flex items-center gap-2 text-xs text-muted-foreground">
                          <User className="w-3 h-3" />
                          {post.author}
                        </span>
                        <span className="text-sm text-accent font-medium group-hover:underline">
                          Read More
                        </span>
                      </div>
                    </div>
                  </article>
                </FadeIn>
              ))}
            </StaggerContainer>
          </div>
        </section>

        {/* Newsletter CTA */}
        <section className="py-16 lg:py-24 bg-card border-t border-border">
          <div className="container mx-auto px-4 lg:px-8 text-center">
            <FadeIn>
              <h2 className="font-[family-name:var(--font-inter-tight)] text-3xl md:text-4xl font-bold text-foreground mb-4">
                Stay Updated
              </h2>
              <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
                Have a question or want to discuss a project? Get in touch with our team.
              </p>
              <Button asChild size="lg" className="bg-accent hover:bg-accent/90 text-accent-foreground font-semibold">
                <Link href="/contact">
                  Contact Us
                  <ArrowRight className="ml-2 w-4 h-4" />
                </Link>
              </Button>
            </FadeIn>
          </div>
        </section>
      </main>
      <Footer />
    </>
  )
}
