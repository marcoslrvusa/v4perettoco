import { Metadata } from 'next'
import Link from 'next/link'
import { Building2, ArrowRight, Hammer, PaintBucket, LayoutGrid, Square, Thermometer, Wallpaper, Box, DoorOpen, Ruler, Sparkles, Eraser, Sparkle } from 'lucide-react'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { SectionHeading, FadeIn, StaggerContainer, staggerItem } from '@/components/animations'
import { Button } from '@/components/ui/button'
import { services } from '@/lib/data/services'

export const metadata: Metadata = {
  title: 'Our Services | Commercial Construction Services',
  description: 'Premium Contractors offers comprehensive commercial construction services including metal framing, drywall, painting, acoustical ceilings, and more. Serving NJ & NY since 1988.',
}

const iconMap: Record<string, React.ElementType> = {
  frame: Building2,
  layers: LayoutGrid,
  paintbrush: PaintBucket,
  grid3x3: LayoutGrid,
  box: Box,
  thermometer: Thermometer,
  wallpaper: Wallpaper,
  square: Square,
  cabinet: Box,
  doorOpen: DoorOpen,
  ruler: Ruler,
  sparkles: Sparkles,
  road: Hammer,
  eraser: Eraser,
  sparkle: Sparkle,
}

export default function ServicesPage() {
  return (
    <>
      <Navbar />
      <main className="pb-16 lg:pb-0">
        {/* Hero */}
        <section className="pt-32 pb-16 lg:pb-24 relative noise-bg">
          <div className="absolute inset-0 bg-gradient-to-br from-background via-primary/50 to-background" />
          <div className="absolute inset-0 grid-pattern opacity-30" />
          
          <div className="container mx-auto px-4 lg:px-8 relative z-10">
            <FadeIn className="max-w-3xl">
              <span className="inline-block px-4 py-1.5 text-xs font-mono uppercase tracking-wider bg-accent/10 text-accent rounded-full mb-4">
                Our Services
              </span>
              <h1 className="font-[family-name:var(--font-inter-tight)] text-4xl md:text-5xl lg:text-6xl font-black text-foreground mb-6">
                Complete Commercial Construction Services
              </h1>
              <p className="text-xl text-muted-foreground">
                From metal framing to finish trimming, Premium Contractors delivers comprehensive construction services for hotels, restaurants, and commercial buildings throughout New Jersey and New York.
              </p>
            </FadeIn>
          </div>
        </section>

        {/* Services Grid */}
        <section className="py-16 lg:py-24">
          <div className="container mx-auto px-4 lg:px-8">
            <StaggerContainer className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {services.map((service) => {
                const Icon = iconMap[service.icon] || Building2
                return (
                  <FadeIn key={service.slug}>
                    <Link
                      href={`/services/${service.slug}`}
                      className="group flex flex-col h-full p-6 bg-card border border-border rounded-xl hover:border-accent/50 transition-all duration-300"
                    >
                      <div className="w-14 h-14 bg-accent/10 rounded-lg flex items-center justify-center mb-4 group-hover:bg-accent/20 transition-colors">
                        <Icon className="w-7 h-7 text-accent" />
                      </div>
                      <h2 className="font-[family-name:var(--font-inter-tight)] text-xl font-bold text-foreground mb-2 group-hover:text-accent transition-colors">
                        {service.name}
                      </h2>
                      <p className="text-muted-foreground mb-4 flex-1">
                        {service.shortDescription}
                      </p>
                      <div className="flex items-center text-sm text-accent font-medium">
                        Learn More
                        <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
                      </div>
                    </Link>
                  </FadeIn>
                )
              })}
            </StaggerContainer>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-16 lg:py-24 bg-card border-t border-border">
          <div className="container mx-auto px-4 lg:px-8 text-center">
            <SectionHeading
              title="Ready to Start Your Project?"
              description="Contact us today for a free consultation and quote on your commercial construction project."
            />
            <FadeIn delay={0.2} className="mt-8">
              <Button asChild size="lg" className="bg-accent hover:bg-accent/90 text-accent-foreground font-semibold">
                <Link href="/contact">
                  Get a Free Quote
                  <ArrowRight className="ml-2 w-4 h-4" />
                </Link>
              </Button>
            </FadeIn>
          </div>
        </section>
      </main>
      <Footer />
      
      {/* Schema Markup */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "ItemList",
            "itemListElement": services.map((service, index) => ({
              "@type": "ListItem",
              "position": index + 1,
              "item": {
                "@type": "Service",
                "name": service.name,
                "description": service.shortDescription,
                "url": `https://www.premiumcontractorllc.com/services/${service.slug}`,
                "provider": {
                  "@type": "GeneralContractor",
                  "name": "Premium Contractors LLC"
                }
              }
            }))
          })
        }}
      />
    </>
  )
}
