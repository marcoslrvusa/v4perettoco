import { Metadata } from 'next'
import { notFound } from 'next/navigation'
import Link from 'next/link'
import { ArrowRight, ArrowLeft, CheckCircle2, Building2, Phone } from 'lucide-react'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { FadeIn, StaggerContainer, staggerItem } from '@/components/animations'
import { Button } from '@/components/ui/button'
import { services } from '@/lib/data/services'
import { projects } from '@/lib/data/projects'

interface ServicePageProps {
  params: Promise<{ slug: string }>
}

export async function generateStaticParams() {
  return services.map((service) => ({
    slug: service.slug,
  }))
}

export async function generateMetadata({ params }: ServicePageProps): Promise<Metadata> {
  const { slug } = await params
  const service = services.find((s) => s.slug === slug)
  
  if (!service) {
    return {
      title: 'Service Not Found',
    }
  }

  return {
    title: `${service.name} Services in NJ & NY`,
    description: service.description,
    openGraph: {
      title: `${service.name} Services | Premium Contractors LLC`,
      description: service.description,
    },
  }
}

export default async function ServicePage({ params }: ServicePageProps) {
  const { slug } = await params
  const service = services.find((s) => s.slug === slug)

  if (!service) {
    notFound()
  }

  // Find related projects
  const relatedProjects = projects.filter(p => 
    p.scope.some(s => s.toLowerCase().includes(service.name.toLowerCase().split(' ')[0]))
  ).slice(0, 3)

  // Get adjacent services for navigation
  const currentIndex = services.findIndex(s => s.slug === slug)
  const prevService = currentIndex > 0 ? services[currentIndex - 1] : null
  const nextService = currentIndex < services.length - 1 ? services[currentIndex + 1] : null

  return (
    <>
      <Navbar />
      <main className="pb-16 lg:pb-0">
        {/* Hero */}
        <section className="pt-32 pb-16 lg:pb-24 relative noise-bg">
          <div className="absolute inset-0 bg-gradient-to-br from-background via-primary/50 to-background" />
          <div className="absolute inset-0 grid-pattern opacity-30" />
          
          <div className="container mx-auto px-4 lg:px-8 relative z-10">
            {/* Breadcrumbs */}
            <FadeIn className="mb-8">
              <nav className="flex items-center gap-2 text-sm text-muted-foreground">
                <Link href="/" className="hover:text-foreground transition-colors">Home</Link>
                <span>/</span>
                <Link href="/services" className="hover:text-foreground transition-colors">Services</Link>
                <span>/</span>
                <span className="text-foreground">{service.name}</span>
              </nav>
            </FadeIn>

            <div className="max-w-4xl">
              <FadeIn>
                <span className="inline-block px-4 py-1.5 text-xs font-mono uppercase tracking-wider bg-accent/10 text-accent rounded-full mb-4">
                  Service
                </span>
                <h1 className="font-[family-name:var(--font-inter-tight)] text-4xl md:text-5xl lg:text-6xl font-black text-foreground mb-6">
                  {service.name}
                </h1>
                <p className="text-xl text-muted-foreground mb-8">
                  {service.description}
                </p>
                <div className="flex flex-col sm:flex-row gap-4">
                  <Button asChild size="lg" className="bg-accent hover:bg-accent/90 text-accent-foreground font-semibold">
                    <Link href="/contact">
                      Get a Quote for {service.name}
                      <ArrowRight className="ml-2 w-4 h-4" />
                    </Link>
                  </Button>
                  <Button asChild variant="outline" size="lg">
                    <a href="tel:+19735585226">
                      <Phone className="mr-2 w-4 h-4" />
                      Call Us Now
                    </a>
                  </Button>
                </div>
              </FadeIn>
            </div>
          </div>
        </section>

        {/* Features */}
        <section className="py-16 lg:py-24">
          <div className="container mx-auto px-4 lg:px-8">
            <div className="grid lg:grid-cols-2 gap-12">
              <FadeIn>
                <h2 className="font-[family-name:var(--font-inter-tight)] text-3xl font-bold text-foreground mb-6">
                  What We Offer
                </h2>
                <p className="text-muted-foreground mb-8">
                  Premium Contractors delivers professional {service.name.toLowerCase()} services for commercial projects throughout New Jersey and New York. Our experienced crews are trained to meet the demanding standards of hotel, restaurant, and commercial construction.
                </p>
                <StaggerContainer className="space-y-4">
                  {service.features.map((feature, index) => (
                    <FadeIn key={feature} delay={index * 0.1}>
                      <div className="flex items-start gap-3">
                        <CheckCircle2 className="w-5 h-5 text-accent mt-0.5 shrink-0" />
                        <span className="text-foreground">{feature}</span>
                      </div>
                    </FadeIn>
                  ))}
                </StaggerContainer>
              </FadeIn>

              <FadeIn delay={0.2}>
                <div className="bg-card border border-border rounded-xl p-8">
                  <h3 className="font-[family-name:var(--font-inter-tight)] text-xl font-bold text-foreground mb-6">
                    Why Choose Premium Contractors?
                  </h3>
                  <ul className="space-y-4">
                    <li className="flex items-start gap-3">
                      <div className="w-8 h-8 bg-accent/10 rounded-lg flex items-center justify-center shrink-0">
                        <span className="text-sm font-bold text-accent">37+</span>
                      </div>
                      <div>
                        <span className="font-medium text-foreground">Years of Experience</span>
                        <p className="text-sm text-muted-foreground">Trusted expertise since 1988</p>
                      </div>
                    </li>
                    <li className="flex items-start gap-3">
                      <div className="w-8 h-8 bg-accent/10 rounded-lg flex items-center justify-center shrink-0">
                        <Building2 className="w-4 h-4 text-accent" />
                      </div>
                      <div>
                        <span className="font-medium text-foreground">Commercial Focus</span>
                        <p className="text-sm text-muted-foreground">Specialized in hotels, restaurants, and commercial buildings</p>
                      </div>
                    </li>
                    <li className="flex items-start gap-3">
                      <div className="w-8 h-8 bg-accent/10 rounded-lg flex items-center justify-center shrink-0">
                        <CheckCircle2 className="w-4 h-4 text-accent" />
                      </div>
                      <div>
                        <span className="font-medium text-foreground">Quality Guaranteed</span>
                        <p className="text-sm text-muted-foreground">Meeting the highest industry standards</p>
                      </div>
                    </li>
                  </ul>
                </div>
              </FadeIn>
            </div>
          </div>
        </section>

        {/* Related Projects */}
        {relatedProjects.length > 0 && (
          <section className="py-16 lg:py-24 bg-card/50 border-t border-border">
            <div className="container mx-auto px-4 lg:px-8">
              <FadeIn>
                <h2 className="font-[family-name:var(--font-inter-tight)] text-3xl font-bold text-foreground mb-8">
                  Related Projects
                </h2>
              </FadeIn>
              <StaggerContainer className="grid md:grid-cols-3 gap-6">
                {relatedProjects.map((project, index) => (
                  <FadeIn key={project.slug} delay={index * 0.1}>
                    <Link
                      href={`/projects/${project.slug}`}
                      className="group block bg-card border border-border rounded-xl overflow-hidden hover:border-accent/50 transition-all"
                    >
                      <div className="aspect-video relative bg-muted">
                        <div className="absolute inset-0 flex items-center justify-center">
                          <Building2 className="w-12 h-12 text-muted-foreground/30" />
                        </div>
                      </div>
                      <div className="p-6">
                        <span className="text-xs text-muted-foreground">{project.location}</span>
                        <h3 className="font-[family-name:var(--font-inter-tight)] font-bold text-foreground group-hover:text-accent transition-colors mt-1">
                          {project.name}
                        </h3>
                      </div>
                    </Link>
                  </FadeIn>
                ))}
              </StaggerContainer>
            </div>
          </section>
        )}

        {/* CTA */}
        <section className="py-16 lg:py-24 border-t border-border">
          <div className="container mx-auto px-4 lg:px-8 text-center">
            <FadeIn>
              <h2 className="font-[family-name:var(--font-inter-tight)] text-3xl md:text-4xl font-bold text-foreground mb-4">
                Ready to Get Started?
              </h2>
              <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
                Contact us today for a free consultation and quote on your {service.name.toLowerCase()} project.
              </p>
              <Button asChild size="lg" className="bg-accent hover:bg-accent/90 text-accent-foreground font-semibold">
                <Link href="/contact">
                  Request a Quote
                  <ArrowRight className="ml-2 w-4 h-4" />
                </Link>
              </Button>
            </FadeIn>
          </div>
        </section>

        {/* Service Navigation */}
        <section className="py-8 border-t border-border">
          <div className="container mx-auto px-4 lg:px-8">
            <div className="flex items-center justify-between">
              {prevService ? (
                <Link
                  href={`/services/${prevService.slug}`}
                  className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span className="hidden sm:inline">{prevService.name}</span>
                  <span className="sm:hidden">Previous</span>
                </Link>
              ) : (
                <div />
              )}
              <Link
                href="/services"
                className="text-sm text-muted-foreground hover:text-foreground transition-colors"
              >
                All Services
              </Link>
              {nextService ? (
                <Link
                  href={`/services/${nextService.slug}`}
                  className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
                >
                  <span className="hidden sm:inline">{nextService.name}</span>
                  <span className="sm:hidden">Next</span>
                  <ArrowRight className="w-4 h-4" />
                </Link>
              ) : (
                <div />
              )}
            </div>
          </div>
        </section>
      </main>
      <Footer />

      {/* Schema Markup */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "Service",
            "serviceType": service.name,
            "provider": {
              "@type": "GeneralContractor",
              "name": "Premium Contractors LLC",
              "url": "https://www.premiumcontractorllc.com"
            },
            "areaServed": [
              { "@type": "State", "name": "New Jersey" },
              { "@type": "State", "name": "New York" }
            ],
            "description": service.description,
          })
        }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "BreadcrumbList",
            "itemListElement": [
              { "@type": "ListItem", "position": 1, "name": "Home", "item": "https://www.premiumcontractorllc.com" },
              { "@type": "ListItem", "position": 2, "name": "Services", "item": "https://www.premiumcontractorllc.com/services" },
              { "@type": "ListItem", "position": 3, "name": service.name, "item": `https://www.premiumcontractorllc.com/services/${service.slug}` }
            ]
          })
        }}
      />
    </>
  )
}
