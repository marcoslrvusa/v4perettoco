import { NextResponse } from 'next/server'
import { services } from '@/lib/data/services'
import { projects } from '@/lib/data/projects'

const llmsFullTxt = `# Premium Contractors LLC - Complete Information

> Commercial construction company serving New Jersey and New York since 1988. Full-service general contractor specializing in hotel, restaurant, and commercial construction.

## Company Overview
- **Legal Name:** Premium Contractors LLC
- **Founded:** 1988
- **Headquarters:** 107 Vesey St, Newark, NJ 07105
- **Phone:** 973-558-5226 / 973-204-2310
- **Email:** office@premiumcontractorllc.com
- **Service Area:** New Jersey and New York
- **President & Founder:** Diniz Teixeira
- **Years in Business:** 37+
- **Projects Completed:** 250+
- **Client Partners:** 50+

## Leadership Team
1. **Diniz Teixeira** - President & Founder
   - Founded Premium Contractors in 1988
   - 37+ years of commercial construction experience
   
2. **Emerson Rodrigues** - Finance Director
   - Oversees all financial operations
   
3. **Brenda Souza** - Office Manager
   - Manages daily operations and client communications
   
4. **Robert Firme** - Project Manager
   - Coordinates crews and ensures quality standards
   
5. **Italo Bacelar** - Project Assistant
   - Supports project management operations

## Complete Services List

${services.map((service, index) => `### ${index + 1}. ${service.name}
${service.description}

**Capabilities:**
${service.features.map(f => `- ${f}`).join('\n')}
`).join('\n')}

## Portfolio Highlights

${projects.map((project, index) => `### ${index + 1}. ${project.name}
- **Location:** ${project.location}
- **Type:** ${project.type}
- **Client:** ${project.client}
- **Scope:** ${project.scope.join(', ')}
- **Description:** ${project.description}
`).join('\n')}

## Key Clients & Partners
- Marriott International (Fairfield Inn, Courtyard, and other brands)
- Hilton Hotels (Garden Inn, Hampton Inn)
- Wendy's (The Briad Group franchise locations)
- The Briad Group (multi-brand restaurant and hotel operator)
- Signature Aviation (FBO facilities)
- Various private developers and property management companies

## Industries Served

### Hospitality
- New hotel construction
- Hotel renovations and remodels
- Brand-standard compliance
- Guest room build-outs
- Lobby and common areas
- Restaurant and kitchen facilities

### Restaurant & Food Service
- New restaurant construction
- Restaurant renovations
- Kitchen build-outs
- Fast-casual concepts
- Full-service restaurants
- Multi-location programs

### Multifamily Residential
- New multifamily construction
- Apartment renovations
- Common area build-outs
- Unit interior finishes
- Amenity spaces

### Commercial Office & Retail
- Office build-outs
- Tenant improvements
- Retail construction
- Corporate headquarters
- Medical offices

## Company Values
1. **Quality** - We deliver exceptional craftsmanship on every project, meeting and exceeding industry standards.
2. **Innovation** - We embrace new techniques and technologies to improve efficiency and results.
3. **Integrity** - We operate with honesty and transparency in all business relationships.
4. **Collaboration** - We work closely with clients, architects, and trades to achieve shared goals.

## Vision Statement
"To be the LEADING CONSTRUCTION COMPANY in the USA, delivering unmatched quality and service to our clients."

## Safety Commitment
- OSHA 10 & OSHA 30 Certified crews
- Comprehensive safety management program
- Regular safety audits and training
- Full workers' compensation and liability insurance
- Licensed contractor in NJ and NY

## Service Area Geography
- **New Jersey:** Newark, Jersey City, Elizabeth, Atlantic City, and statewide
- **New York:** New York City metro area, Long Island, Hudson Valley

## Contact Information
- **Main Office:** 107 Vesey St, Newark, NJ 07105
- **Phone:** 973-558-5226
- **Alternative Phone:** 973-204-2310
- **Email:** office@premiumcontractorllc.com
- **LinkedIn:** https://www.linkedin.com/company/premium-contractorsllc
- **Website:** https://www.premiumcontractorllc.com

## Hours of Operation
Monday - Friday: 7:00 AM - 5:00 PM

## Website Navigation
- Home: https://www.premiumcontractorllc.com
- About: https://www.premiumcontractorllc.com/about
- Services: https://www.premiumcontractorllc.com/services
- Projects: https://www.premiumcontractorllc.com/projects
- Team: https://www.premiumcontractorllc.com/team
- Contact: https://www.premiumcontractorllc.com/contact
- FAQ: https://www.premiumcontractorllc.com/faq
- Careers: https://www.premiumcontractorllc.com/careers
- Safety: https://www.premiumcontractorllc.com/safety
`

export async function GET() {
  return new NextResponse(llmsFullTxt, {
    headers: {
      'Content-Type': 'text/plain; charset=utf-8',
    },
  })
}
