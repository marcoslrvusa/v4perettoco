import { Metadata } from 'next'
import Link from 'next/link'
import { ArrowRight, Briefcase, Heart, TrendingUp, Users, CheckCircle2, Mail } from 'lucide-react'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { SectionHeading, FadeIn, StaggerContainer } from '@/components/animations'
import { Button } from '@/components/ui/button'

export const metadata: Metadata = {
  title: 'Careers | Join Our Team',
  description: 'Explore career opportunities at Premium Contractors LLC. Join a team with 37+ years of commercial construction excellence in New Jersey and New York.',
}

const benefits = [
  {
    icon: TrendingUp,
    title: 'Growth Opportunities',
    description: 'We invest in our people. Advance your career with training and development programs.'
  },
  {
    icon: Heart,
    title: 'Competitive Benefits',
    description: 'Health insurance, retirement plans, paid time off, and more to support you and your family.'
  },
  {
    icon: Users,
    title: 'Team Environment',
    description: 'Work alongside skilled professionals who take pride in their craft and support each other.'
  },
  {
    icon: Briefcase,
    title: 'Stable Employment',
    description: '37+ years in business means job security and a consistent pipeline of projects.'
  },
]

const openPositions = [
  {
    title: 'Metal Framing Foreman',
    location: 'Newark, NJ',
    type: 'Full-time',
    description: 'Lead metal framing crews on commercial construction projects throughout NJ/NY.'
  },
  {
    title: 'Drywall Finisher',
    location: 'Newark, NJ',
    type: 'Full-time',
    description: 'Experienced finisher for taping, spackling, and smooth finish work on commercial projects.'
  },
  {
    title: 'Commercial Painter',
    location: 'Newark, NJ',
    type: 'Full-time',
    description: 'Interior and exterior commercial painting for hotels, offices, and retail spaces.'
  },
  {
    title: 'Project Coordinator',
    location: 'Newark, NJ',
    type: 'Full-time',
    description: 'Support project managers with scheduling, documentation, and field coordination.'
  },
]

export default function CareersPage() {
  return (
    <>
      <Navbar />
      <main className="pb-16 lg:pb-0">
        {/* Hero */}
        <section className="pt-32 pb-16 lg:pb-24 relative noise-bg">
          <div className="absolute inset-0 bg-gradient-to-br from-background via-primary/50 to-background" />
          <div className="absolute inset-0 grid-pattern opacity-30" />
          
          <div className="container mx-auto px-4 lg:px-8 relative z-10">
            <FadeIn className="max-w-3xl">
              <span className="inline-block px-4 py-1.5 text-xs font-mono uppercase tracking-wider bg-accent/10 text-accent rounded-full mb-4">
                Careers
              </span>
              <h1 className="font-[family-name:var(--font-inter-tight)] text-4xl md:text-5xl lg:text-6xl font-black text-foreground mb-6">
                Build Your Career With Us
              </h1>
              <p className="text-xl text-muted-foreground">
                Join a team with 37+ years of commercial construction excellence. We&apos;re always looking for skilled professionals who share our commitment to quality.
              </p>
            </FadeIn>
          </div>
        </section>

        {/* Why Join Us */}
        <section className="py-16 lg:py-24">
          <div className="container mx-auto px-4 lg:px-8">
            <SectionHeading
              badge="Why Join Us"
              title="Benefits of Working at Premium Contractors"
              description="We take care of our team so they can take care of our clients."
            />
            <StaggerContainer className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mt-12">
              {benefits.map((benefit) => {
                const Icon = benefit.icon
                return (
                  <FadeIn key={benefit.title}>
                    <div className="p-6 bg-card border border-border rounded-xl h-full">
                      <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center mb-4">
                        <Icon className="w-6 h-6 text-accent" />
                      </div>
                      <h3 className="font-[family-name:var(--font-inter-tight)] text-lg font-bold text-foreground mb-2">
                        {benefit.title}
                      </h3>
                      <p className="text-sm text-muted-foreground">
                        {benefit.description}
                      </p>
                    </div>
                  </FadeIn>
                )
              })}
            </StaggerContainer>
          </div>
        </section>

        {/* Open Positions */}
        <section className="py-16 lg:py-24 bg-card/50 border-y border-border">
          <div className="container mx-auto px-4 lg:px-8">
            <SectionHeading
              badge="Open Positions"
              title="Current Opportunities"
              description="Explore our open positions and find your fit."
            />
            <StaggerContainer className="space-y-4 mt-12 max-w-3xl mx-auto">
              {openPositions.map((position) => (
                <FadeIn key={position.title}>
                  <div className="p-6 bg-card border border-border rounded-xl hover:border-accent/50 transition-colors">
                    <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                      <div>
                        <h3 className="font-[family-name:var(--font-inter-tight)] text-lg font-bold text-foreground mb-1">
                          {position.title}
                        </h3>
                        <div className="flex items-center gap-4 text-sm text-muted-foreground mb-2">
                          <span>{position.location}</span>
                          <span>&bull;</span>
                          <span>{position.type}</span>
                        </div>
                        <p className="text-sm text-muted-foreground">
                          {position.description}
                        </p>
                      </div>
                      <Button asChild className="shrink-0 bg-accent hover:bg-accent/90 text-accent-foreground">
                        <a href={`mailto:careers@premiumcontractorllc.com?subject=Application: ${position.title}`}>
                          Apply Now
                        </a>
                      </Button>
                    </div>
                  </div>
                </FadeIn>
              ))}
            </StaggerContainer>
          </div>
        </section>

        {/* What We Look For */}
        <section className="py-16 lg:py-24">
          <div className="container mx-auto px-4 lg:px-8">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <FadeIn>
                <h2 className="font-[family-name:var(--font-inter-tight)] text-3xl font-bold text-foreground mb-6">
                  What We Look For
                </h2>
                <p className="text-muted-foreground mb-6">
                  We&apos;re always interested in hearing from experienced construction professionals who share our values of quality, integrity, and teamwork.
                </p>
                <ul className="space-y-3">
                  <li className="flex items-center gap-3">
                    <CheckCircle2 className="w-5 h-5 text-accent shrink-0" />
                    <span className="text-foreground">Commitment to safety</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <CheckCircle2 className="w-5 h-5 text-accent shrink-0" />
                    <span className="text-foreground">Quality craftsmanship</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <CheckCircle2 className="w-5 h-5 text-accent shrink-0" />
                    <span className="text-foreground">Team player attitude</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <CheckCircle2 className="w-5 h-5 text-accent shrink-0" />
                    <span className="text-foreground">Reliability and professionalism</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <CheckCircle2 className="w-5 h-5 text-accent shrink-0" />
                    <span className="text-foreground">Willingness to learn and grow</span>
                  </li>
                </ul>
              </FadeIn>
              <FadeIn delay={0.2}>
                <div className="bg-card border border-border rounded-xl p-8 text-center">
                  <Mail className="w-12 h-12 text-accent mx-auto mb-4" />
                  <h3 className="font-[family-name:var(--font-inter-tight)] text-xl font-bold text-foreground mb-2">
                    Don&apos;t See Your Role?
                  </h3>
                  <p className="text-muted-foreground mb-6">
                    We&apos;re always looking for talented people. Send us your resume and we&apos;ll keep you in mind for future opportunities.
                  </p>
                  <Button asChild className="bg-accent hover:bg-accent/90 text-accent-foreground">
                    <a href="mailto:careers@premiumcontractorllc.com">
                      Send Your Resume
                      <ArrowRight className="ml-2 w-4 h-4" />
                    </a>
                  </Button>
                </div>
              </FadeIn>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  )
}
