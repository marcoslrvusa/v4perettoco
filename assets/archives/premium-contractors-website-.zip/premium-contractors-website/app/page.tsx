import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { MobileFloatingCTA } from '@/components/sticky-form'
import { 
  HeroSection, 
  ClientsSection, 
  AboutPreviewSection,
  ServicesSection,
  FeaturedProjectsSection,
  TestimonialSection,
  StatsSection,
  WhyChooseUsSection,
  CTASection 
} from '@/components/home-sections'

export default function HomePage() {
  return (
    <>
      <Navbar />
      <main className="pb-20 lg:pb-0">
        {/* Hero - Full Width Dark */}
        <HeroSection />
        
        {/* Clients Trust Bar - White */}
        <ClientsSection />
        
        {/* About Preview - Dark */}
        <AboutPreviewSection />
        
        {/* Services - White */}
        <ServicesSection />
        
        {/* Projects - Dark */}
        <FeaturedProjectsSection />
        
        {/* Why Choose Us - White */}
        <WhyChooseUsSection />
        
        {/* Testimonial - White with subtle bg */}
        <TestimonialSection />
        
        {/* Stats Bar - Dark */}
        <StatsSection />
        
        {/* Final CTA - Dark with Image */}
        <CTASection />
        
        {/* Mobile Floating CTA */}
        <MobileFloatingCTA />
      </main>
      <Footer />
    </>
  )
}
