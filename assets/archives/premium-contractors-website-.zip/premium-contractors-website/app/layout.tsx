import type { Metadata } from 'next'
import { Inter, Playfair_Display, JetBrains_Mono } from 'next/font/google'
import { Analytics } from '@vercel/analytics/next'
import './globals.css'

const inter = Inter({ 
  subsets: ["latin"],
  variable: '--font-inter',
  display: 'swap',
})

const playfair = Playfair_Display({ 
  subsets: ["latin"],
  variable: '--font-playfair',
  weight: ['400', '500', '600', '700'],
  display: 'swap',
})

const jetbrainsMono = JetBrains_Mono({ 
  subsets: ["latin"],
  variable: '--font-jetbrains-mono',
  display: 'swap',
})

export const metadata: Metadata = {
  metadataBase: new URL('https://www.premiumcontractorllc.com'),
  title: {
    default: 'Premium Contractors LLC | Commercial Construction Excellence in NJ & NY Since 1988',
    template: '%s | Premium Contractors LLC'
  },
  description: 'Premium Contractors LLC is a premier commercial construction company serving New Jersey and New York since 1988. Specializing in luxury hotel, restaurant, and commercial construction for Marriott, Hilton, and elite hospitality brands.',
  keywords: ['commercial construction', 'general contractor', 'metal framing', 'drywall', 'hotel construction', 'New Jersey contractor', 'New York contractor', 'Newark construction', 'luxury hospitality construction', 'Marriott contractor', 'Hilton contractor'],
  authors: [{ name: 'Premium Contractors LLC' }],
  creator: 'Premium Contractors LLC',
  publisher: 'Premium Contractors LLC',
  formatDetection: {
    email: false,
    address: false,
    telephone: false,
  },
  openGraph: {
    type: 'website',
    locale: 'en_US',
    url: 'https://www.premiumcontractorllc.com',
    siteName: 'Premium Contractors LLC',
    title: 'Premium Contractors LLC | Commercial Construction Excellence in NJ & NY Since 1988',
    description: 'Premier commercial construction company serving New Jersey and New York since 1988. Specializing in luxury hotel, restaurant, and commercial construction.',
    images: [
      {
        url: '/images/hero-construction.jpg',
        width: 1200,
        height: 630,
        alt: 'Premium Contractors LLC - Commercial Construction Excellence',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Premium Contractors LLC | Commercial Construction Excellence',
    description: 'Premier commercial construction company serving NJ & NY since 1988.',
    images: ['/images/hero-construction.jpg'],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
  icons: {
    icon: [
      { url: '/favicon.ico' },
      { url: '/icon.svg', type: 'image/svg+xml' },
    ],
    apple: '/apple-icon.png',
  },
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className={`${inter.variable} ${playfair.variable} ${jetbrainsMono.variable} bg-background`}>
      <head>
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "GeneralContractor",
              "name": "Premium Contractors LLC",
              "description": "Premier commercial construction company serving New Jersey and New York since 1988. Specializing in luxury hotel, restaurant, and commercial construction.",
              "url": "https://www.premiumcontractorllc.com",
              "telephone": "+1-973-558-5226",
              "email": "office@premiumcontractorllc.com",
              "foundingDate": "1988",
              "founder": {
                "@type": "Person",
                "name": "Diniz Teixeira"
              },
              "address": {
                "@type": "PostalAddress",
                "streetAddress": "107 Vesey St",
                "addressLocality": "Newark",
                "addressRegion": "NJ",
                "postalCode": "07105",
                "addressCountry": "US"
              },
              "geo": {
                "@type": "GeoCoordinates",
                "latitude": 40.7271,
                "longitude": -74.1706
              },
              "openingHoursSpecification": [
                {
                  "@type": "OpeningHoursSpecification",
                  "dayOfWeek": ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
                  "opens": "07:00",
                  "closes": "17:00"
                }
              ],
              "areaServed": [
                { "@type": "State", "name": "New Jersey" },
                { "@type": "State", "name": "New York" }
              ],
              "priceRange": "$$$",
              "image": "https://www.premiumcontractorllc.com/images/hero-construction.jpg",
              "sameAs": [
                "https://www.linkedin.com/company/premium-contractorsllc"
              ],
              "hasOfferCatalog": {
                "@type": "OfferCatalog",
                "name": "Construction Services",
                "itemListElement": [
                  { "@type": "Offer", "itemOffered": { "@type": "Service", "name": "Metal Framing" } },
                  { "@type": "Offer", "itemOffered": { "@type": "Service", "name": "Drywall Installation" } },
                  { "@type": "Offer", "itemOffered": { "@type": "Service", "name": "Commercial Painting" } },
                  { "@type": "Offer", "itemOffered": { "@type": "Service", "name": "Acoustical Ceilings" } },
                  { "@type": "Offer", "itemOffered": { "@type": "Service", "name": "Ceramic Tile Installation" } }
                ]
              },
              "aggregateRating": {
                "@type": "AggregateRating",
                "ratingValue": "4.9",
                "reviewCount": "127"
              }
            })
          }}
        />
      </head>
      <body className="font-sans antialiased min-h-screen">
        {children}
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
