import { Metadata } from 'next'
import Link from 'next/link'
import { ArrowRight } from 'lucide-react'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { FadeIn } from '@/components/animations'
import { Button } from '@/components/ui/button'
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion"

export const metadata: Metadata = {
  title: 'FAQ | Frequently Asked Questions',
  description: 'Find answers to common questions about Premium Contractors LLC commercial construction services, project process, service areas, and more.',
}

const faqs = [
  {
    question: "What areas does Premium Contractors serve?",
    answer: "We serve commercial clients throughout New Jersey and New York from our headquarters in Newark, NJ. Our teams are experienced in working on projects across both states, from urban centers to suburban locations."
  },
  {
    question: "What types of commercial projects do you handle?",
    answer: "We specialize in hotel construction, restaurant build-outs, multifamily residential, and general commercial spaces. Our services include metal framing, drywall, painting, acoustical ceilings, flooring, and more. We work with major brands like Marriott, Hilton, and Wendy's."
  },
  {
    question: "How long has Premium Contractors been in business?",
    answer: "We've been delivering quality construction since 1988 — over 37 years of experience. Founded by Diniz Teixeira, we've completed more than 250 projects and built lasting relationships with industry-leading clients."
  },
  {
    question: "Do you work with major hotel brands?",
    answer: "Yes. We are trusted partners of Marriott, Hilton, and other premier hospitality brands. Our teams are trained in brand standards and have extensive experience meeting the specific requirements of hotel construction."
  },
  {
    question: "What is your project process?",
    answer: "Our process begins with an initial consultation to understand your project needs. We then provide a detailed proposal and timeline. Once approved, our project managers coordinate all trades, maintain quality control, and keep you informed throughout construction until final completion."
  },
  {
    question: "Are you licensed and insured?",
    answer: "Yes, Premium Contractors LLC is fully licensed and insured to perform commercial construction work in New Jersey and New York. We maintain comprehensive liability coverage and workers' compensation insurance."
  },
  {
    question: "How do I get a quote for my project?",
    answer: "You can request a quote by filling out our contact form, calling us at 973-558-5226, or emailing office@premiumcontractorllc.com. We'll schedule a consultation to discuss your project requirements and provide a detailed estimate."
  },
  {
    question: "What sets Premium Contractors apart from other contractors?",
    answer: "Our 37+ years of experience, focus on commercial construction, and commitment to quality set us apart. We have a proven track record with major brands, skilled crews trained in the latest techniques, and a dedication to delivering projects on time and on budget."
  },
  {
    question: "Do you handle permits and inspections?",
    answer: "Yes, we assist with the permitting process and coordinate all required inspections throughout the project. Our team is familiar with local building codes and requirements in both New Jersey and New York."
  },
  {
    question: "Can you work within an active business environment?",
    answer: "Absolutely. We have extensive experience working in active commercial environments, including operational hotels, restaurants, and office buildings. We coordinate carefully to minimize disruption to your business operations."
  },
]

export default function FAQPage() {
  return (
    <>
      <Navbar />
      <main className="pb-16 lg:pb-0">
        {/* Hero */}
        <section className="pt-32 pb-16 lg:pb-24 relative noise-bg">
          <div className="absolute inset-0 bg-gradient-to-br from-background via-primary/50 to-background" />
          <div className="absolute inset-0 grid-pattern opacity-30" />
          
          <div className="container mx-auto px-4 lg:px-8 relative z-10">
            <FadeIn className="max-w-3xl">
              <span className="inline-block px-4 py-1.5 text-xs font-mono uppercase tracking-wider bg-accent/10 text-accent rounded-full mb-4">
                FAQ
              </span>
              <h1 className="font-[family-name:var(--font-inter-tight)] text-4xl md:text-5xl lg:text-6xl font-black text-foreground mb-6">
                Frequently Asked Questions
              </h1>
              <p className="text-xl text-muted-foreground">
                Find answers to common questions about our commercial construction services, process, and capabilities.
              </p>
            </FadeIn>
          </div>
        </section>

        {/* FAQ Content */}
        <section className="py-16 lg:py-24">
          <div className="container mx-auto px-4 lg:px-8">
            <div className="max-w-3xl mx-auto">
              <FadeIn>
                <Accordion type="single" collapsible className="space-y-4">
                  {faqs.map((faq, index) => (
                    <AccordionItem 
                      key={index} 
                      value={`item-${index}`}
                      className="bg-card border border-border rounded-lg px-6 data-[state=open]:border-accent/50"
                    >
                      <AccordionTrigger className="text-left font-[family-name:var(--font-inter-tight)] font-semibold text-foreground hover:text-accent py-6 hover:no-underline">
                        {faq.question}
                      </AccordionTrigger>
                      <AccordionContent className="text-muted-foreground pb-6">
                        {faq.answer}
                      </AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              </FadeIn>
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="py-16 lg:py-24 bg-card border-t border-border">
          <div className="container mx-auto px-4 lg:px-8 text-center">
            <FadeIn>
              <h2 className="font-[family-name:var(--font-inter-tight)] text-3xl md:text-4xl font-bold text-foreground mb-4">
                Still Have Questions?
              </h2>
              <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
                Can&apos;t find what you&apos;re looking for? Our team is here to help.
              </p>
              <Button asChild size="lg" className="bg-accent hover:bg-accent/90 text-accent-foreground font-semibold">
                <Link href="/contact">
                  Contact Us
                  <ArrowRight className="ml-2 w-4 h-4" />
                </Link>
              </Button>
            </FadeIn>
          </div>
        </section>
      </main>
      <Footer />

      {/* FAQ Schema */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "FAQPage",
            "mainEntity": faqs.map(faq => ({
              "@type": "Question",
              "name": faq.question,
              "acceptedAnswer": {
                "@type": "Answer",
                "text": faq.answer
              }
            }))
          })
        }}
      />
    </>
  )
}
