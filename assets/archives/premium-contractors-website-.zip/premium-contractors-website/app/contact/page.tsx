"use client"

import { useState } from 'react'
import Image from 'next/image'
import Link from 'next/link'
import { motion } from 'framer-motion'
import { Phone, Mail, MapPin, Clock, CheckCircle2, ArrowRight, Loader2, Shield, Award, Star, Building2 } from 'lucide-react'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'

export default function ContactPage() {
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSubmitted, setIsSubmitted] = useState(false)

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setIsSubmitting(true)
    
    // In production, this would submit to Go High Level webhook
    // Example: https://services.leadconnectorhq.com/hooks/YOUR_WEBHOOK_ID
    await new Promise(resolve => setTimeout(resolve, 1500))
    
    setIsSubmitting(false)
    setIsSubmitted(true)
  }

  return (
    <>
      <Navbar />
      <main className="pb-20 lg:pb-0">
        {/* Hero Section */}
        <section className="relative pt-32 pb-20 lg:pb-32 overflow-hidden">
          <div className="absolute inset-0">
            <Image
              src="/images/aerial-building.jpg"
              alt="Commercial construction"
              fill
              className="object-cover"
              priority
            />
            <div className="absolute inset-0 bg-primary/90" />
          </div>
          
          <div className="container mx-auto px-4 lg:px-8 relative z-10">
            <motion.div 
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="max-w-3xl"
            >
              <p className="text-sm font-medium uppercase tracking-[0.2em] text-accent mb-4">
                Contact Us
              </p>
              <h1 className="font-[family-name:var(--font-playfair)] text-4xl md:text-5xl lg:text-6xl font-semibold text-white mb-6 leading-tight">
                Let&apos;s Build Something
                <br />
                <span className="text-accent">Extraordinary Together</span>
              </h1>
              <p className="text-xl text-white/80 leading-relaxed">
                Ready to start your commercial construction project? Our team is here to 
                bring your vision to life with precision, expertise, and uncompromising quality.
              </p>
            </motion.div>
          </div>
        </section>

        {/* Main Content */}
        <section className="py-20 lg:py-28 bg-white">
          <div className="container mx-auto px-4 lg:px-8">
            <div className="grid lg:grid-cols-5 gap-12 lg:gap-16">
              
              {/* Contact Info - Left Side */}
              <motion.div 
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
                className="lg:col-span-2"
              >
                <h2 className="font-[family-name:var(--font-playfair)] text-3xl font-semibold text-foreground mb-8">
                  Get in Touch
                </h2>
                
                <div className="space-y-6 mb-10">
                  <a 
                    href="tel:+19735585226"
                    className="flex items-start gap-4 group p-4 rounded-xl hover:bg-secondary transition-colors"
                  >
                    <div className="w-14 h-14 bg-accent/10 rounded-xl flex items-center justify-center shrink-0 group-hover:bg-accent group-hover:scale-105 transition-all">
                      <Phone className="w-6 h-6 text-accent group-hover:text-white transition-colors" />
                    </div>
                    <div>
                      <p className="font-semibold text-foreground group-hover:text-accent transition-colors text-lg">Phone</p>
                      <p className="text-muted-foreground font-mono">(973) 558-5226</p>
                      <p className="text-muted-foreground font-mono">(973) 204-2310</p>
                    </div>
                  </a>

                  <a 
                    href="mailto:office@premiumcontractorllc.com"
                    className="flex items-start gap-4 group p-4 rounded-xl hover:bg-secondary transition-colors"
                  >
                    <div className="w-14 h-14 bg-accent/10 rounded-xl flex items-center justify-center shrink-0 group-hover:bg-accent group-hover:scale-105 transition-all">
                      <Mail className="w-6 h-6 text-accent group-hover:text-white transition-colors" />
                    </div>
                    <div>
                      <p className="font-semibold text-foreground group-hover:text-accent transition-colors text-lg">Email</p>
                      <p className="text-muted-foreground">office@premiumcontractorllc.com</p>
                    </div>
                  </a>

                  <a 
                    href="https://maps.google.com/?q=107+Vesey+St,+Newark,+NJ+07105"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-start gap-4 group p-4 rounded-xl hover:bg-secondary transition-colors"
                  >
                    <div className="w-14 h-14 bg-accent/10 rounded-xl flex items-center justify-center shrink-0 group-hover:bg-accent group-hover:scale-105 transition-all">
                      <MapPin className="w-6 h-6 text-accent group-hover:text-white transition-colors" />
                    </div>
                    <div>
                      <p className="font-semibold text-foreground group-hover:text-accent transition-colors text-lg">Address</p>
                      <p className="text-muted-foreground">107 Vesey St</p>
                      <p className="text-muted-foreground">Newark, NJ 07105</p>
                    </div>
                  </a>

                  <div className="flex items-start gap-4 p-4">
                    <div className="w-14 h-14 bg-accent/10 rounded-xl flex items-center justify-center shrink-0">
                      <Clock className="w-6 h-6 text-accent" />
                    </div>
                    <div>
                      <p className="font-semibold text-foreground text-lg">Business Hours</p>
                      <p className="text-muted-foreground">Monday - Friday</p>
                      <p className="text-muted-foreground">7:00 AM - 5:00 PM</p>
                    </div>
                  </div>
                </div>

                {/* Trust Signals */}
                <div className="bg-secondary rounded-2xl p-6">
                  <h3 className="font-semibold text-foreground mb-4">Why Choose Premium Contractors</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="flex items-center gap-2">
                      <Award className="w-5 h-5 text-accent" />
                      <span className="text-sm text-muted-foreground">37+ Years</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Shield className="w-5 h-5 text-accent" />
                      <span className="text-sm text-muted-foreground">Licensed & Insured</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Building2 className="w-5 h-5 text-accent" />
                      <span className="text-sm text-muted-foreground">127+ Projects</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Star className="w-5 h-5 text-accent" />
                      <span className="text-sm text-muted-foreground">4.9/5 Rating</span>
                    </div>
                  </div>
                </div>
              </motion.div>

              {/* Contact Form - Right Side (Go High Level Ready) */}
              <motion.div 
                initial={{ opacity: 0, x: 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: 0.2 }}
                className="lg:col-span-3"
              >
                <div className="bg-white border border-border rounded-2xl shadow-xl p-8 md:p-10">
                  {/* Form Header */}
                  <div className="text-center mb-8">
                    <h2 className="font-[family-name:var(--font-playfair)] text-3xl font-semibold text-foreground mb-2">
                      Request Your Free Quote
                    </h2>
                    <p className="text-muted-foreground">
                      Fill out the form below and we&apos;ll respond within 24 hours.
                    </p>
                  </div>

                  {isSubmitted ? (
                    <motion.div 
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className="text-center py-12"
                    >
                      <div className="w-20 h-20 bg-accent/10 rounded-full flex items-center justify-center mx-auto mb-6">
                        <CheckCircle2 className="w-10 h-10 text-accent" />
                      </div>
                      <h3 className="font-[family-name:var(--font-playfair)] text-2xl font-semibold text-foreground mb-3">
                        Thank You!
                      </h3>
                      <p className="text-muted-foreground mb-8 max-w-md mx-auto">
                        We&apos;ve received your request and a member of our team will contact you within 24 hours.
                      </p>
                      <Button onClick={() => setIsSubmitted(false)} variant="outline" size="lg">
                        Send Another Request
                      </Button>
                    </motion.div>
                  ) : (
                    /* 
                      GO HIGH LEVEL INTEGRATION:
                      Replace the form action with your GHL webhook URL:
                      action="https://services.leadconnectorhq.com/hooks/YOUR_WEBHOOK_ID"
                      
                      Or embed a GHL form directly:
                      <iframe src="https://api.leadconnectorhq.com/widget/form/YOUR_FORM_ID" ...></iframe>
                    */
                    <form 
                      onSubmit={handleSubmit} 
                      className="space-y-6"
                      // action="https://services.leadconnectorhq.com/hooks/YOUR_WEBHOOK_ID"
                      // method="POST"
                    >
                      <div className="grid md:grid-cols-2 gap-6">
                        <div>
                          <label htmlFor="full_name" className="block text-sm font-medium text-foreground mb-2">
                            Full Name *
                          </label>
                          <input
                            type="text"
                            id="full_name"
                            name="full_name"
                            required
                            className="w-full px-4 py-3.5 bg-secondary border border-border rounded-xl text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent focus:border-transparent transition-all"
                            placeholder="John Smith"
                          />
                        </div>
                        <div>
                          <label htmlFor="company" className="block text-sm font-medium text-foreground mb-2">
                            Company Name
                          </label>
                          <input
                            type="text"
                            id="company"
                            name="company"
                            className="w-full px-4 py-3.5 bg-secondary border border-border rounded-xl text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent focus:border-transparent transition-all"
                            placeholder="Your Company"
                          />
                        </div>
                      </div>

                      <div className="grid md:grid-cols-2 gap-6">
                        <div>
                          <label htmlFor="email" className="block text-sm font-medium text-foreground mb-2">
                            Email Address *
                          </label>
                          <input
                            type="email"
                            id="email"
                            name="email"
                            required
                            className="w-full px-4 py-3.5 bg-secondary border border-border rounded-xl text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent focus:border-transparent transition-all"
                            placeholder="john@company.com"
                          />
                        </div>
                        <div>
                          <label htmlFor="phone" className="block text-sm font-medium text-foreground mb-2">
                            Phone Number *
                          </label>
                          <input
                            type="tel"
                            id="phone"
                            name="phone"
                            required
                            className="w-full px-4 py-3.5 bg-secondary border border-border rounded-xl text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent focus:border-transparent transition-all"
                            placeholder="(555) 000-0000"
                          />
                        </div>
                      </div>

                      <div>
                        <label htmlFor="project_type" className="block text-sm font-medium text-foreground mb-2">
                          Project Type *
                        </label>
                        <select
                          id="project_type"
                          name="project_type"
                          required
                          className="w-full px-4 py-3.5 bg-secondary border border-border rounded-xl text-foreground focus:outline-none focus:ring-2 focus:ring-accent focus:border-transparent transition-all"
                        >
                          <option value="">Select project type</option>
                          <option value="Hotel / Hospitality">Hotel / Hospitality</option>
                          <option value="Restaurant / Food Service">Restaurant / Food Service</option>
                          <option value="Commercial Office">Commercial Office</option>
                          <option value="Multifamily Residential">Multifamily Residential</option>
                          <option value="Retail Space">Retail Space</option>
                          <option value="Healthcare Facility">Healthcare Facility</option>
                          <option value="Other">Other</option>
                        </select>
                      </div>

                      <div className="grid md:grid-cols-2 gap-6">
                        <div>
                          <label htmlFor="project_location" className="block text-sm font-medium text-foreground mb-2">
                            Project Location
                          </label>
                          <input
                            type="text"
                            id="project_location"
                            name="project_location"
                            className="w-full px-4 py-3.5 bg-secondary border border-border rounded-xl text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent focus:border-transparent transition-all"
                            placeholder="City, State"
                          />
                        </div>
                        <div>
                          <label htmlFor="timeline" className="block text-sm font-medium text-foreground mb-2">
                            Desired Timeline
                          </label>
                          <select
                            id="timeline"
                            name="timeline"
                            className="w-full px-4 py-3.5 bg-secondary border border-border rounded-xl text-foreground focus:outline-none focus:ring-2 focus:ring-accent focus:border-transparent transition-all"
                          >
                            <option value="">Select timeline</option>
                            <option value="Immediately">Immediately</option>
                            <option value="1-3 months">1-3 months</option>
                            <option value="3-6 months">3-6 months</option>
                            <option value="6+ months">6+ months</option>
                            <option value="Just exploring">Just exploring</option>
                          </select>
                        </div>
                      </div>

                      <div>
                        <label htmlFor="message" className="block text-sm font-medium text-foreground mb-2">
                          Project Details
                        </label>
                        <textarea
                          id="message"
                          name="message"
                          rows={4}
                          className="w-full px-4 py-3.5 bg-secondary border border-border rounded-xl text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent focus:border-transparent transition-all resize-none"
                          placeholder="Tell us about your project - scope, square footage, special requirements, etc."
                        />
                      </div>

                      {/* Hidden fields for tracking */}
                      <input type="hidden" name="source" value="website_contact_form" />

                      <Button 
                        type="submit" 
                        size="lg" 
                        className="w-full bg-accent hover:bg-accent/90 text-accent-foreground font-semibold h-14 text-lg"
                        disabled={isSubmitting}
                      >
                        {isSubmitting ? (
                          <>
                            <Loader2 className="mr-2 w-5 h-5 animate-spin" />
                            Submitting...
                          </>
                        ) : (
                          <>
                            Get My Free Quote
                            <ArrowRight className="ml-2 w-5 h-5" />
                          </>
                        )}
                      </Button>

                      {/* Trust indicators */}
                      <div className="flex flex-wrap items-center justify-center gap-6 pt-4">
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <CheckCircle2 className="w-4 h-4 text-accent" />
                          <span>Free Consultation</span>
                        </div>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <CheckCircle2 className="w-4 h-4 text-accent" />
                          <span>24hr Response</span>
                        </div>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <CheckCircle2 className="w-4 h-4 text-accent" />
                          <span>No Obligation</span>
                        </div>
                      </div>
                    </form>
                  )}
                </div>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Map Section */}
        <section className="py-20 bg-secondary border-t border-border">
          <div className="container mx-auto px-4 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="text-center mb-12"
            >
              <h2 className="font-[family-name:var(--font-playfair)] text-3xl font-semibold text-foreground mb-4">
                Visit Our Office
              </h2>
              <p className="text-muted-foreground">
                Conveniently located in Newark, NJ - serving the entire tri-state area.
              </p>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="aspect-[16/9] md:aspect-[21/9] rounded-2xl overflow-hidden border border-border shadow-lg"
            >
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3024.2219901290355!2d-74.17279368459518!3d40.72707197933052!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c2537a5c5c5c5d%3A0x1c5c5c5c5c5c5c5c!2s107%20Vesey%20St%2C%20Newark%2C%20NJ%2007105!5e0!3m2!1sen!2sus!4v1620000000000!5m2!1sen!2sus"
                width="100%"
                height="100%"
                style={{ border: 0 }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                title="Premium Contractors LLC Location"
              />
            </motion.div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  )
}
