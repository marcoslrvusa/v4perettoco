import { Metadata } from 'next'
import { notFound } from 'next/navigation'
import Link from 'next/link'
import { ArrowRight, ArrowLeft, MapPin, Building2, CheckCircle2 } from 'lucide-react'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { FadeIn, StaggerContainer, staggerItem } from '@/components/animations'
import { Button } from '@/components/ui/button'
import { projects } from '@/lib/data/projects'

interface ProjectPageProps {
  params: Promise<{ slug: string }>
}

export async function generateStaticParams() {
  return projects.map((project) => ({
    slug: project.slug,
  }))
}

export async function generateMetadata({ params }: ProjectPageProps): Promise<Metadata> {
  const { slug } = await params
  const project = projects.find((p) => p.slug === slug)
  
  if (!project) {
    return {
      title: 'Project Not Found',
    }
  }

  return {
    title: `${project.name} | Commercial Construction Project`,
    description: project.description,
    openGraph: {
      title: `${project.name} | Premium Contractors LLC`,
      description: project.description,
    },
  }
}

export default async function ProjectPage({ params }: ProjectPageProps) {
  const { slug } = await params
  const project = projects.find((p) => p.slug === slug)

  if (!project) {
    notFound()
  }

  // Get adjacent projects for navigation
  const currentIndex = projects.findIndex(p => p.slug === slug)
  const prevProject = currentIndex > 0 ? projects[currentIndex - 1] : null
  const nextProject = currentIndex < projects.length - 1 ? projects[currentIndex + 1] : null

  // Get related projects (same type)
  const relatedProjects = projects
    .filter(p => p.type === project.type && p.slug !== project.slug)
    .slice(0, 2)

  return (
    <>
      <Navbar />
      <main className="pb-16 lg:pb-0">
        {/* Hero */}
        <section className="pt-32 pb-16 lg:pb-24 relative noise-bg">
          <div className="absolute inset-0 bg-gradient-to-br from-background via-primary/50 to-background" />
          <div className="absolute inset-0 grid-pattern opacity-30" />
          
          <div className="container mx-auto px-4 lg:px-8 relative z-10">
            {/* Breadcrumbs */}
            <FadeIn className="mb-8">
              <nav className="flex items-center gap-2 text-sm text-muted-foreground">
                <Link href="/" className="hover:text-foreground transition-colors">Home</Link>
                <span>/</span>
                <Link href="/projects" className="hover:text-foreground transition-colors">Projects</Link>
                <span>/</span>
                <span className="text-foreground">{project.name}</span>
              </nav>
            </FadeIn>

            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <FadeIn>
                <div className="flex items-center gap-3 mb-4">
                  <span className="px-3 py-1 text-xs font-mono uppercase tracking-wider bg-accent/10 text-accent rounded-full">
                    {project.type}
                  </span>
                  {project.featured && (
                    <span className="px-3 py-1 text-xs font-mono uppercase tracking-wider bg-accent text-accent-foreground rounded-full">
                      Featured
                    </span>
                  )}
                </div>
                <h1 className="font-[family-name:var(--font-inter-tight)] text-4xl md:text-5xl font-black text-foreground mb-4">
                  {project.name}
                </h1>
                <div className="flex items-center gap-2 text-muted-foreground mb-6">
                  <MapPin className="w-4 h-4" />
                  <span>{project.location}</span>
                </div>
                <p className="text-lg text-muted-foreground mb-8">
                  {project.description}
                </p>
                <Button asChild size="lg" className="bg-accent hover:bg-accent/90 text-accent-foreground font-semibold">
                  <Link href="/contact">
                    Start a Similar Project
                    <ArrowRight className="ml-2 w-4 h-4" />
                  </Link>
                </Button>
              </FadeIn>

              <FadeIn delay={0.2}>
                <div className="aspect-[4/3] relative bg-card border border-border rounded-xl overflow-hidden">
                  <div className="absolute inset-0 flex items-center justify-center">
                    <Building2 className="w-24 h-24 text-muted-foreground/20" />
                  </div>
                </div>
              </FadeIn>
            </div>
          </div>
        </section>

        {/* Project Details */}
        <section className="py-16 lg:py-24">
          <div className="container mx-auto px-4 lg:px-8">
            <div className="grid lg:grid-cols-3 gap-12">
              {/* Main Content */}
              <div className="lg:col-span-2">
                <FadeIn>
                  <h2 className="font-[family-name:var(--font-inter-tight)] text-2xl font-bold text-foreground mb-6">
                    Project Overview
                  </h2>
                  <p className="text-muted-foreground mb-8 text-lg">
                    {project.description}
                  </p>
                </FadeIn>

                <FadeIn delay={0.1}>
                  <h3 className="font-[family-name:var(--font-inter-tight)] text-xl font-bold text-foreground mb-4">
                    Project Highlights
                  </h3>
                  <ul className="space-y-3 mb-8">
                    {project.highlights.map((highlight, index) => (
                      <li key={index} className="flex items-start gap-3">
                        <CheckCircle2 className="w-5 h-5 text-accent mt-0.5 shrink-0" />
                        <span className="text-foreground">{highlight}</span>
                      </li>
                    ))}
                  </ul>
                </FadeIn>

                <FadeIn delay={0.2}>
                  <h3 className="font-[family-name:var(--font-inter-tight)] text-xl font-bold text-foreground mb-4">
                    Services Provided
                  </h3>
                  <div className="flex flex-wrap gap-2">
                    {project.scope.map((service) => (
                      <Link
                        key={service}
                        href={`/services/${service.toLowerCase().replace(/\s+/g, '-')}`}
                        className="px-4 py-2 bg-card border border-border rounded-lg text-sm text-foreground hover:border-accent/50 hover:text-accent transition-colors"
                      >
                        {service}
                      </Link>
                    ))}
                  </div>
                </FadeIn>
              </div>

              {/* Sidebar */}
              <div className="lg:col-span-1">
                <FadeIn delay={0.3}>
                  <div className="bg-card border border-border rounded-xl p-6 sticky top-28">
                    <h3 className="font-[family-name:var(--font-inter-tight)] text-lg font-bold text-foreground mb-6">
                      Project Details
                    </h3>
                    <dl className="space-y-4">
                      <div>
                        <dt className="text-sm text-muted-foreground">Client</dt>
                        <dd className="text-foreground font-medium">{project.client}</dd>
                      </div>
                      <div>
                        <dt className="text-sm text-muted-foreground">Location</dt>
                        <dd className="text-foreground font-medium">{project.location}</dd>
                      </div>
                      <div>
                        <dt className="text-sm text-muted-foreground">Project Type</dt>
                        <dd className="text-foreground font-medium">{project.type}</dd>
                      </div>
                      <div>
                        <dt className="text-sm text-muted-foreground">Scope</dt>
                        <dd className="text-foreground font-medium">{project.scope.length} services</dd>
                      </div>
                    </dl>

                    <hr className="my-6 border-border" />

                    <Button asChild className="w-full bg-accent hover:bg-accent/90 text-accent-foreground font-semibold">
                      <Link href="/contact">
                        Discuss Your Project
                      </Link>
                    </Button>
                  </div>
                </FadeIn>
              </div>
            </div>
          </div>
        </section>

        {/* Related Projects */}
        {relatedProjects.length > 0 && (
          <section className="py-16 lg:py-24 bg-card/50 border-t border-border">
            <div className="container mx-auto px-4 lg:px-8">
              <FadeIn>
                <h2 className="font-[family-name:var(--font-inter-tight)] text-3xl font-bold text-foreground mb-8">
                  Similar Projects
                </h2>
              </FadeIn>
              <StaggerContainer className="grid md:grid-cols-2 gap-8">
                {relatedProjects.map((relatedProject, index) => (
                  <FadeIn key={relatedProject.slug} delay={index * 0.1}>
                    <Link
                      href={`/projects/${relatedProject.slug}`}
                      className="group block bg-card border border-border rounded-xl overflow-hidden hover:border-accent/50 transition-all"
                    >
                      <div className="aspect-video relative bg-muted">
                        <div className="absolute inset-0 flex items-center justify-center">
                          <Building2 className="w-16 h-16 text-muted-foreground/30" />
                        </div>
                      </div>
                      <div className="p-6">
                        <div className="flex items-center gap-2 mb-2">
                          <span className="px-2 py-1 text-xs font-mono bg-accent/10 text-accent rounded">
                            {relatedProject.type}
                          </span>
                          <span className="text-xs text-muted-foreground">{relatedProject.location}</span>
                        </div>
                        <h3 className="font-[family-name:var(--font-inter-tight)] text-xl font-bold text-foreground group-hover:text-accent transition-colors">
                          {relatedProject.name}
                        </h3>
                      </div>
                    </Link>
                  </FadeIn>
                ))}
              </StaggerContainer>
            </div>
          </section>
        )}

        {/* Project Navigation */}
        <section className="py-8 border-t border-border">
          <div className="container mx-auto px-4 lg:px-8">
            <div className="flex items-center justify-between">
              {prevProject ? (
                <Link
                  href={`/projects/${prevProject.slug}`}
                  className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span className="hidden sm:inline">{prevProject.name}</span>
                  <span className="sm:hidden">Previous</span>
                </Link>
              ) : (
                <div />
              )}
              <Link
                href="/projects"
                className="text-sm text-muted-foreground hover:text-foreground transition-colors"
              >
                All Projects
              </Link>
              {nextProject ? (
                <Link
                  href={`/projects/${nextProject.slug}`}
                  className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
                >
                  <span className="hidden sm:inline">{nextProject.name}</span>
                  <span className="sm:hidden">Next</span>
                  <ArrowRight className="w-4 h-4" />
                </Link>
              ) : (
                <div />
              )}
            </div>
          </div>
        </section>
      </main>
      <Footer />

      {/* Schema Markup */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "CreativeWork",
            "name": project.name,
            "description": project.description,
            "locationCreated": {
              "@type": "Place",
              "name": project.location
            },
            "creator": {
              "@type": "GeneralContractor",
              "name": "Premium Contractors LLC",
              "url": "https://www.premiumcontractorllc.com"
            }
          })
        }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "BreadcrumbList",
            "itemListElement": [
              { "@type": "ListItem", "position": 1, "name": "Home", "item": "https://www.premiumcontractorllc.com" },
              { "@type": "ListItem", "position": 2, "name": "Projects", "item": "https://www.premiumcontractorllc.com/projects" },
              { "@type": "ListItem", "position": 3, "name": project.name, "item": `https://www.premiumcontractorllc.com/projects/${project.slug}` }
            ]
          })
        }}
      />
    </>
  )
}
