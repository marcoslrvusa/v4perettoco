"use client"

import { useState } from 'react'
import Link from 'next/link'
import Image from 'next/image'
import { motion } from 'framer-motion'
import { ArrowRight, Filter, MapPin } from 'lucide-react'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { MobileFloatingCTA } from '@/components/sticky-form'
import { FadeIn, StaggerContainer, staggerItem } from '@/components/animations'
import { Button } from '@/components/ui/button'
import { projects } from '@/lib/data/projects'

const projectTypes = ['All', 'Hospitality', 'Multifamily', 'Commercial', 'Restaurant']

const projectImages: Record<string, string> = {
  'marriott-newark-airport': '/images/project-1.jpg',
  'hilton-garden-inn-renovation': '/images/hotel-lobby.jpg',
  'wendys-locations': '/images/restaurant-interior.jpg',
  'urban-heights-apartments': '/images/project-3.jpg',
  'signature-aviation-terminal': '/images/aerial-building.jpg',
}

export default function ProjectsPage() {
  const [activeFilter, setActiveFilter] = useState('All')

  const filteredProjects = activeFilter === 'All' 
    ? projects 
    : projects.filter(p => p.type === activeFilter)

  return (
    <>
      <Navbar />
      <main className="pb-20 lg:pb-0">
        {/* Hero */}
        <section className="relative pt-32 pb-20 lg:pb-28 overflow-hidden">
          <div className="absolute inset-0">
            <Image
              src="/images/aerial-building.jpg"
              alt="Commercial construction projects"
              fill
              className="object-cover"
              priority
            />
            <div className="absolute inset-0 bg-primary/90" />
          </div>
          
          <div className="container mx-auto px-4 lg:px-8 relative z-10">
            <motion.div 
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="max-w-3xl"
            >
              <p className="text-sm font-medium uppercase tracking-[0.2em] text-accent mb-4">
                Our Portfolio
              </p>
              <h1 className="font-[family-name:var(--font-playfair)] text-4xl md:text-5xl lg:text-6xl font-semibold text-white mb-6 leading-tight">
                Projects That Define
                <br />
                <span className="text-accent">Excellence</span>
              </h1>
              <p className="text-xl text-white/80 leading-relaxed">
                Explore our portfolio of completed commercial construction projects 
                across New Jersey and New York, featuring luxury hotels, upscale 
                restaurants, and premier multifamily developments.
              </p>
            </motion.div>
          </div>
        </section>

        {/* Filter */}
        <section className="py-6 border-b border-border sticky top-20 bg-white/98 backdrop-blur-md z-20">
          <div className="container mx-auto px-4 lg:px-8">
            <div className="flex items-center gap-4 overflow-x-auto pb-2">
              <Filter className="w-5 h-5 text-muted-foreground shrink-0" />
              {projectTypes.map((type) => (
                <button
                  key={type}
                  onClick={() => setActiveFilter(type)}
                  className={`px-5 py-2.5 text-sm font-medium rounded-full whitespace-nowrap transition-all ${
                    activeFilter === type
                      ? 'bg-accent text-accent-foreground'
                      : 'bg-secondary text-muted-foreground hover:text-foreground hover:bg-secondary/80'
                  }`}
                >
                  {type}
                </button>
              ))}
            </div>
          </div>
        </section>

        {/* Projects Grid */}
        <section className="py-16 lg:py-24 bg-white">
          <div className="container mx-auto px-4 lg:px-8">
            <StaggerContainer className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredProjects.map((project, index) => (
                <motion.div 
                  key={project.slug}
                  variants={staggerItem}
                  className="group"
                >
                  <Link 
                    href={`/projects/${project.slug}`}
                    className="block bg-white border border-border rounded-2xl overflow-hidden hover:border-accent/50 transition-all duration-300 hover:shadow-xl"
                  >
                    <div className="aspect-[4/3] relative overflow-hidden">
                      <Image
                        src={projectImages[project.slug] || `/images/project-${(index % 3) + 1}.jpg`}
                        alt={project.name}
                        fill
                        className="object-cover group-hover:scale-105 transition-transform duration-500"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />
                      {project.featured && (
                        <span className="absolute top-4 left-4 z-20 px-3 py-1 text-xs font-medium bg-accent text-white rounded-full">
                          Featured
                        </span>
                      )}
                      <div className="absolute bottom-4 left-4 right-4">
                        <span className="inline-block px-3 py-1 text-xs font-medium bg-white/20 backdrop-blur-sm text-white rounded-full mb-2">
                          {project.type}
                        </span>
                      </div>
                    </div>
                    <div className="p-6">
                      <h2 className="font-[family-name:var(--font-playfair)] text-xl font-semibold text-foreground mb-2 group-hover:text-accent transition-colors">
                        {project.name}
                      </h2>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground mb-3">
                        <MapPin className="w-4 h-4" />
                        {project.location}
                      </div>
                      <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
                        {project.description}
                      </p>
                      <div className="flex flex-wrap gap-2 mb-4">
                        {project.scope.slice(0, 3).map((service) => (
                          <span key={service} className="text-xs text-muted-foreground bg-secondary px-2 py-1 rounded">
                            {service}
                          </span>
                        ))}
                        {project.scope.length > 3 && (
                          <span className="text-xs text-accent bg-accent/10 px-2 py-1 rounded">
                            +{project.scope.length - 3} more
                          </span>
                        )}
                      </div>
                      <div className="flex items-center text-sm text-accent font-medium">
                        View Case Study
                        <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
                      </div>
                    </div>
                  </Link>
                </motion.div>
              ))}
            </StaggerContainer>

            {filteredProjects.length === 0 && (
              <div className="text-center py-16">
                <p className="text-muted-foreground">No projects found for this category.</p>
              </div>
            )}
          </div>
        </section>

        {/* CTA Section */}
        <section className="relative py-20 lg:py-28 overflow-hidden">
          <div className="absolute inset-0">
            <Image
              src="/images/hero-construction.jpg"
              alt="Commercial construction"
              fill
              className="object-cover"
            />
            <div className="absolute inset-0 bg-primary/90" />
          </div>
          
          <div className="container mx-auto px-4 lg:px-8 text-center relative z-10">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <p className="text-sm font-medium uppercase tracking-[0.2em] text-accent mb-4">
                Start Your Project
              </p>
              <h2 className="font-[family-name:var(--font-playfair)] text-3xl md:text-4xl lg:text-5xl font-semibold text-white mb-6">
                Want Your Project
                <br />
                <span className="text-accent">Featured Here?</span>
              </h2>
              <p className="text-lg text-white/80 mb-10 max-w-2xl mx-auto">
                Let&apos;s discuss how Premium Contractors can bring your commercial 
                construction vision to life with the same excellence you see here.
              </p>
              <Button asChild size="lg" className="bg-accent hover:bg-accent/90 text-accent-foreground font-semibold text-lg px-8 h-14">
                <Link href="/contact">
                  Start Your Project
                  <ArrowRight className="ml-2 w-5 h-5" />
                </Link>
              </Button>
            </motion.div>
          </div>
        </section>
        
        <MobileFloatingCTA />
      </main>
      <Footer />
    </>
  )
}
