import { Metadata } from 'next'
import { notFound } from 'next/navigation'
import Link from 'next/link'
import { ArrowRight, Building2, CheckCircle2, Hotel, UtensilsCrossed, Building } from 'lucide-react'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { FadeIn, StaggerContainer, SectionHeading } from '@/components/animations'
import { Button } from '@/components/ui/button'
import { projects } from '@/lib/data/projects'

interface IndustryPageProps {
  params: Promise<{ slug: string }>
}

const industries = {
  hospitality: {
    name: 'Hospitality',
    icon: Hotel,
    title: 'Hotel & Hospitality Construction',
    description: 'Premium Contractors specializes in hotel construction for leading hospitality brands. Our experienced teams deliver brand-standard results for Marriott, Hilton, and other premier hotel chains.',
    services: [
      'New hotel construction',
      'Hotel renovations & remodels',
      'Brand-standard compliance',
      'Guest room build-outs',
      'Lobby & common area construction',
      'Restaurant & kitchen facilities'
    ],
    stats: [
      { label: 'Hotel Projects', value: '50+' },
      { label: 'Brand Partners', value: '10+' },
      { label: 'States Served', value: '2' },
    ]
  },
  multifamily: {
    name: 'Multifamily',
    icon: Building2,
    title: 'Multifamily Residential Construction',
    description: 'We deliver high-quality multifamily residential construction for developers and property management companies. From luxury apartments to affordable housing, our teams handle projects of all sizes.',
    services: [
      'New multifamily construction',
      'Apartment renovations',
      'Common area build-outs',
      'Unit interior finishes',
      'Amenity spaces',
      'Parking structures'
    ],
    stats: [
      { label: 'Units Completed', value: '500+' },
      { label: 'Projects', value: '25+' },
      { label: 'Years Experience', value: '37+' },
    ]
  },
  commercial: {
    name: 'Commercial',
    icon: Building,
    title: 'Commercial Office & Retail Construction',
    description: 'Premium Contractors builds and renovates commercial spaces for businesses across New Jersey and New York. We create productive environments that meet the unique needs of each client.',
    services: [
      'Office build-outs',
      'Tenant improvements',
      'Retail construction',
      'Corporate headquarters',
      'Medical offices',
      'Financial institutions'
    ],
    stats: [
      { label: 'Sq Ft Completed', value: '1M+' },
      { label: 'Commercial Projects', value: '100+' },
      { label: 'Client Retention', value: '95%' },
    ]
  },
  restaurant: {
    name: 'Restaurant',
    icon: UtensilsCrossed,
    title: 'Restaurant & Food Service Construction',
    description: 'We partner with restaurant brands and operators to build and renovate dining establishments. Our teams understand the unique requirements of food service construction.',
    services: [
      'New restaurant construction',
      'Restaurant renovations',
      'Kitchen build-outs',
      'Dining room finishes',
      'Fast-casual concepts',
      'Full-service restaurants'
    ],
    stats: [
      { label: 'Restaurant Projects', value: '75+' },
      { label: "Wendy's Locations", value: '30+' },
      { label: 'Avg Project Time', value: '8 wks' },
    ]
  },
}

export async function generateStaticParams() {
  return Object.keys(industries).map((slug) => ({ slug }))
}

export async function generateMetadata({ params }: IndustryPageProps): Promise<Metadata> {
  const { slug } = await params
  const industry = industries[slug as keyof typeof industries]
  
  if (!industry) {
    return { title: 'Industry Not Found' }
  }

  return {
    title: `${industry.name} Construction Services in NJ & NY`,
    description: industry.description,
  }
}

export default async function IndustryPage({ params }: IndustryPageProps) {
  const { slug } = await params
  const industry = industries[slug as keyof typeof industries]

  if (!industry) {
    notFound()
  }

  const Icon = industry.icon
  
  // Get related projects
  const relatedProjects = projects.filter(p => 
    p.type.toLowerCase() === industry.name.toLowerCase() ||
    (industry.name === 'Restaurant' && p.type === 'Restaurant')
  ).slice(0, 3)

  return (
    <>
      <Navbar />
      <main className="pb-16 lg:pb-0">
        {/* Hero */}
        <section className="pt-32 pb-16 lg:pb-24 relative noise-bg">
          <div className="absolute inset-0 bg-gradient-to-br from-background via-primary/50 to-background" />
          <div className="absolute inset-0 grid-pattern opacity-30" />
          
          <div className="container mx-auto px-4 lg:px-8 relative z-10">
            <FadeIn className="max-w-3xl">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center">
                  <Icon className="w-6 h-6 text-accent" />
                </div>
                <span className="text-sm font-mono uppercase tracking-wider text-muted-foreground">
                  Industry
                </span>
              </div>
              <h1 className="font-[family-name:var(--font-inter-tight)] text-4xl md:text-5xl lg:text-6xl font-black text-foreground mb-6">
                {industry.title}
              </h1>
              <p className="text-xl text-muted-foreground mb-8">
                {industry.description}
              </p>
              <Button asChild size="lg" className="bg-accent hover:bg-accent/90 text-accent-foreground font-semibold">
                <Link href="/contact">
                  Discuss Your {industry.name} Project
                  <ArrowRight className="ml-2 w-4 h-4" />
                </Link>
              </Button>
            </FadeIn>
          </div>
        </section>

        {/* Stats */}
        <section className="py-12 bg-card border-y border-border">
          <div className="container mx-auto px-4 lg:px-8">
            <div className="grid grid-cols-3 gap-8">
              {industry.stats.map((stat) => (
                <div key={stat.label} className="text-center">
                  <div className="font-mono text-3xl md:text-4xl font-bold text-foreground mb-1">
                    {stat.value}
                  </div>
                  <div className="text-sm text-muted-foreground">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Services */}
        <section className="py-16 lg:py-24">
          <div className="container mx-auto px-4 lg:px-8">
            <div className="grid lg:grid-cols-2 gap-12">
              <FadeIn>
                <h2 className="font-[family-name:var(--font-inter-tight)] text-3xl font-bold text-foreground mb-6">
                  Our {industry.name} Services
                </h2>
                <p className="text-muted-foreground mb-8">
                  Premium Contractors offers comprehensive construction services tailored to the unique needs of the {industry.name.toLowerCase()} industry.
                </p>
                <ul className="space-y-4">
                  {industry.services.map((service) => (
                    <li key={service} className="flex items-start gap-3">
                      <CheckCircle2 className="w-5 h-5 text-accent mt-0.5 shrink-0" />
                      <span className="text-foreground">{service}</span>
                    </li>
                  ))}
                </ul>
              </FadeIn>

              <FadeIn delay={0.2}>
                <div className="bg-card border border-border rounded-xl p-8">
                  <h3 className="font-[family-name:var(--font-inter-tight)] text-xl font-bold text-foreground mb-6">
                    Why Choose Premium Contractors?
                  </h3>
                  <ul className="space-y-4 text-muted-foreground">
                    <li className="flex items-start gap-3">
                      <span className="w-8 h-8 bg-accent/10 rounded-lg flex items-center justify-center shrink-0 text-sm font-bold text-accent">1</span>
                      <div>
                        <span className="font-medium text-foreground">Industry Expertise</span>
                        <p className="text-sm">Deep understanding of {industry.name.toLowerCase()} construction requirements</p>
                      </div>
                    </li>
                    <li className="flex items-start gap-3">
                      <span className="w-8 h-8 bg-accent/10 rounded-lg flex items-center justify-center shrink-0 text-sm font-bold text-accent">2</span>
                      <div>
                        <span className="font-medium text-foreground">Proven Track Record</span>
                        <p className="text-sm">37+ years of successful project delivery</p>
                      </div>
                    </li>
                    <li className="flex items-start gap-3">
                      <span className="w-8 h-8 bg-accent/10 rounded-lg flex items-center justify-center shrink-0 text-sm font-bold text-accent">3</span>
                      <div>
                        <span className="font-medium text-foreground">Quality Commitment</span>
                        <p className="text-sm">Meeting brand standards and exceeding expectations</p>
                      </div>
                    </li>
                  </ul>
                </div>
              </FadeIn>
            </div>
          </div>
        </section>

        {/* Related Projects */}
        {relatedProjects.length > 0 && (
          <section className="py-16 lg:py-24 bg-card/50 border-t border-border">
            <div className="container mx-auto px-4 lg:px-8">
              <SectionHeading
                title={`${industry.name} Projects`}
                description={`Explore our completed ${industry.name.toLowerCase()} construction projects.`}
              />
              <StaggerContainer className="grid md:grid-cols-3 gap-8 mt-12">
                {relatedProjects.map((project, index) => (
                  <FadeIn key={project.slug} delay={index * 0.1}>
                    <Link
                      href={`/projects/${project.slug}`}
                      className="group block bg-card border border-border rounded-xl overflow-hidden hover:border-accent/50 transition-all"
                    >
                      <div className="aspect-video relative bg-muted">
                        <div className="absolute inset-0 flex items-center justify-center">
                          <Building2 className="w-12 h-12 text-muted-foreground/30" />
                        </div>
                      </div>
                      <div className="p-6">
                        <span className="text-xs text-muted-foreground">{project.location}</span>
                        <h3 className="font-[family-name:var(--font-inter-tight)] font-bold text-foreground group-hover:text-accent transition-colors mt-1">
                          {project.name}
                        </h3>
                      </div>
                    </Link>
                  </FadeIn>
                ))}
              </StaggerContainer>
              <FadeIn delay={0.3} className="text-center mt-8">
                <Button asChild variant="outline">
                  <Link href="/projects">View All Projects</Link>
                </Button>
              </FadeIn>
            </div>
          </section>
        )}

        {/* CTA */}
        <section className="py-16 lg:py-24 border-t border-border">
          <div className="container mx-auto px-4 lg:px-8 text-center">
            <FadeIn>
              <h2 className="font-[family-name:var(--font-inter-tight)] text-3xl md:text-4xl font-bold text-foreground mb-4">
                Ready to Start Your {industry.name} Project?
              </h2>
              <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
                Contact us today for a free consultation and quote.
              </p>
              <Button asChild size="lg" className="bg-accent hover:bg-accent/90 text-accent-foreground font-semibold">
                <Link href="/contact">
                  Get a Free Quote
                  <ArrowRight className="ml-2 w-4 h-4" />
                </Link>
              </Button>
            </FadeIn>
          </div>
        </section>
      </main>
      <Footer />
    </>
  )
}
