import { Metadata } from 'next'
import Link from 'next/link'
import { ArrowRight, Mail, Linkedin, User } from 'lucide-react'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { SectionHeading, FadeIn, StaggerContainer } from '@/components/animations'
import { Button } from '@/components/ui/button'
import { team } from '@/lib/data/company'

export const metadata: Metadata = {
  title: 'Our Team | Meet the Premium Contractors Leadership',
  description: 'Meet the experienced leadership team behind Premium Contractors LLC. Our skilled professionals bring decades of commercial construction expertise to every project.',
}

export default function TeamPage() {
  return (
    <>
      <Navbar />
      <main className="pb-16 lg:pb-0">
        {/* Hero */}
        <section className="pt-32 pb-16 lg:pb-24 relative noise-bg">
          <div className="absolute inset-0 bg-gradient-to-br from-background via-primary/50 to-background" />
          <div className="absolute inset-0 grid-pattern opacity-30" />
          
          <div className="container mx-auto px-4 lg:px-8 relative z-10">
            <FadeIn className="max-w-3xl">
              <span className="inline-block px-4 py-1.5 text-xs font-mono uppercase tracking-wider bg-accent/10 text-accent rounded-full mb-4">
                Our Team
              </span>
              <h1 className="font-[family-name:var(--font-inter-tight)] text-4xl md:text-5xl lg:text-6xl font-black text-foreground mb-6">
                Meet the Experts
              </h1>
              <p className="text-xl text-muted-foreground">
                Our leadership team brings decades of combined experience in commercial construction, ensuring every project is delivered with excellence.
              </p>
            </FadeIn>
          </div>
        </section>

        {/* Team Grid */}
        <section className="py-16 lg:py-24">
          <div className="container mx-auto px-4 lg:px-8">
            <StaggerContainer className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {team.map((member, index) => (
                <FadeIn key={member.name} delay={index * 0.1}>
                  <div className="bg-card border border-border rounded-xl overflow-hidden group">
                    <div className="aspect-[4/3] relative bg-muted">
                      <div className="absolute inset-0 flex items-center justify-center">
                        <User className="w-20 h-20 text-muted-foreground/30" />
                      </div>
                    </div>
                    <div className="p-6">
                      <h2 className="font-[family-name:var(--font-inter-tight)] text-xl font-bold text-foreground mb-1">
                        {member.name}
                      </h2>
                      <p className="text-accent font-medium mb-4">{member.role}</p>
                      <p className="text-muted-foreground text-sm">
                        {member.bio}
                      </p>
                    </div>
                  </div>
                </FadeIn>
              ))}
            </StaggerContainer>
          </div>
        </section>

        {/* Join Us CTA */}
        <section className="py-16 lg:py-24 bg-card/50 border-t border-border">
          <div className="container mx-auto px-4 lg:px-8 text-center">
            <SectionHeading
              badge="Careers"
              title="Join Our Team"
              description="We&apos;re always looking for skilled professionals who share our commitment to excellence. Explore career opportunities at Premium Contractors."
            />
            <FadeIn delay={0.2} className="flex flex-col sm:flex-row items-center justify-center gap-4 mt-8">
              <Button asChild size="lg" className="bg-accent hover:bg-accent/90 text-accent-foreground font-semibold">
                <Link href="/careers">
                  View Open Positions
                  <ArrowRight className="ml-2 w-4 h-4" />
                </Link>
              </Button>
              <Button asChild variant="outline" size="lg">
                <a href="https://www.linkedin.com/company/premium-contractorsllc" target="_blank" rel="noopener noreferrer">
                  <Linkedin className="mr-2 w-4 h-4" />
                  Follow on LinkedIn
                </a>
              </Button>
            </FadeIn>
          </div>
        </section>

        {/* Contact CTA */}
        <section className="py-16 lg:py-24">
          <div className="container mx-auto px-4 lg:px-8 text-center">
            <FadeIn>
              <h2 className="font-[family-name:var(--font-inter-tight)] text-3xl md:text-4xl font-bold text-foreground mb-4">
                Ready to Start a Conversation?
              </h2>
              <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
                Contact our team to discuss your commercial construction project.
              </p>
              <Button asChild size="lg" className="bg-accent hover:bg-accent/90 text-accent-foreground font-semibold">
                <Link href="/contact">
                  <Mail className="mr-2 w-4 h-4" />
                  Contact Us
                </Link>
              </Button>
            </FadeIn>
          </div>
        </section>
      </main>
      <Footer />

      {/* Schema Markup */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "Organization",
            "name": "Premium Contractors LLC",
            "member": team.map(member => ({
              "@type": "Person",
              "name": member.name,
              "jobTitle": member.role
            }))
          })
        }}
      />
    </>
  )
}
