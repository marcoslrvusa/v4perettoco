import { Metadata } from 'next'
import Link from 'next/link'
import Image from 'next/image'
import { ArrowRight, Target, Lightbulb, Shield, Users, Award, Building2, Quote, CheckCircle2 } from 'lucide-react'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { MobileFloatingCTA } from '@/components/sticky-form'
import { SectionHeading, FadeIn, StaggerContainer, StatsCounter } from '@/components/animations'
import { Button } from '@/components/ui/button'
import { companyValues, companyStats, testimonials } from '@/lib/data/company'

export const metadata: Metadata = {
  title: 'About Us | Commercial Construction Excellence Since 1988',
  description: 'Learn about Premium Contractors LLC, a premier commercial construction company serving New Jersey and New York since 1988. Discover our history, values, and vision.',
}

const valueIcons: Record<string, React.ElementType> = {
  Quality: Award,
  Innovation: Lightbulb,
  Integrity: Shield,
  Collaboration: Users,
}

export default function AboutPage() {
  return (
    <>
      <Navbar />
      <main className="pb-20 lg:pb-0">
        {/* Hero */}
        <section className="relative pt-32 pb-20 lg:pb-28 overflow-hidden">
          <div className="absolute inset-0">
            <Image
              src="/images/team-photo.jpg"
              alt="Premium Contractors team"
              fill
              className="object-cover"
              priority
            />
            <div className="absolute inset-0 bg-primary/90" />
          </div>
          
          <div className="container mx-auto px-4 lg:px-8 relative z-10">
            <FadeIn className="max-w-3xl">
              <p className="text-sm font-medium uppercase tracking-[0.2em] text-accent mb-4">
                About Premium Contractors
              </p>
              <h1 className="font-[family-name:var(--font-playfair)] text-4xl md:text-5xl lg:text-6xl font-semibold text-white mb-6 leading-tight">
                Building Excellence
                <br />
                <span className="text-accent">Since 1988</span>
              </h1>
              <p className="text-xl text-white/80 leading-relaxed">
                For over 37 years, Premium Contractors LLC has been the trusted partner 
                for commercial construction projects across New Jersey and New York, 
                serving the hospitality industry&apos;s most prestigious brands.
              </p>
            </FadeIn>
          </div>
        </section>

        {/* Stats */}
        <section className="py-16 bg-white border-b border-border">
          <div className="container mx-auto px-4 lg:px-8">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
              <StatsCounter value={companyStats.yearsInBusiness} suffix="+" label="Years in Business" />
              <StatsCounter value={companyStats.projectsCompleted} suffix="+" label="Projects Completed" />
              <StatsCounter value={companyStats.clientPartners} suffix="+" label="Client Partners" />
              <div className="text-center">
                <div className="font-[family-name:var(--font-playfair)] text-4xl md:text-5xl font-bold text-foreground mb-2">
                  NJ+NY
                </div>
                <div className="text-sm text-muted-foreground uppercase tracking-wider">
                  Service Areas
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Story */}
        <section className="py-20 lg:py-28 bg-white">
          <div className="container mx-auto px-4 lg:px-8">
            <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
              <FadeIn>
                <p className="text-sm font-medium uppercase tracking-[0.2em] text-accent mb-4">
                  Our Story
                </p>
                <h2 className="font-[family-name:var(--font-playfair)] text-3xl md:text-4xl font-semibold text-foreground mb-6 leading-tight">
                  From Family Business to
                  <br />
                  <span className="text-accent">Industry Leader</span>
                </h2>
                <div className="space-y-5 text-muted-foreground leading-relaxed">
                  <p>
                    Founded in 1988 by Diniz Teixeira, Premium Contractors LLC began with a 
                    simple vision: to deliver commercial construction services that exceed 
                    expectations. Starting from Newark, New Jersey, we have grown into one 
                    of the region&apos;s most trusted construction partners.
                  </p>
                  <p>
                    Over the past 37 years, we have completed more than 250 projects for 
                    clients including Marriott, Hilton, Wendy&apos;s, and The Briad Group. Our 
                    expertise spans hotel construction, restaurant build-outs, multifamily 
                    developments, and commercial spaces.
                  </p>
                  <p>
                    Today, Premium Contractors employs a dedicated team of skilled professionals 
                    who share our commitment to quality, innovation, and integrity. We continue 
                    to build on our foundation of excellence, serving clients throughout New 
                    Jersey and New York.
                  </p>
                </div>
                
                <div className="mt-8 flex flex-wrap gap-4">
                  <Button asChild size="lg" className="bg-accent hover:bg-accent/90 text-accent-foreground font-semibold">
                    <Link href="/contact">
                      Work With Us
                      <ArrowRight className="ml-2 w-4 h-4" />
                    </Link>
                  </Button>
                  <Button asChild variant="outline" size="lg">
                    <Link href="/team">Meet Our Team</Link>
                  </Button>
                </div>
              </FadeIn>
              
              <FadeIn delay={0.2}>
                <div className="relative">
                  <div className="aspect-[4/5] relative rounded-2xl overflow-hidden">
                    <Image
                      src="/images/ceo-portrait.jpg"
                      alt="Diniz Teixeira, Founder & CEO"
                      fill
                      className="object-cover"
                    />
                  </div>
                  {/* Info Card */}
                  <div className="absolute -bottom-6 -right-6 bg-white border border-border p-6 rounded-xl shadow-xl max-w-[280px] hidden md:block">
                    <p className="text-sm text-muted-foreground mb-1">Founder & CEO</p>
                    <p className="font-[family-name:var(--font-playfair)] text-xl font-semibold text-foreground mb-2">
                      Diniz Teixeira
                    </p>
                    <p className="text-sm text-muted-foreground">
                      Leading Premium Contractors since 1988 with a vision of excellence.
                    </p>
                  </div>
                </div>
              </FadeIn>
            </div>
          </div>
        </section>

        {/* Vision - Dark Section */}
        <section className="section-dark py-20 lg:py-28">
          <div className="container mx-auto px-4 lg:px-8">
            <FadeIn className="max-w-4xl mx-auto text-center">
              <Target className="w-16 h-16 text-accent mx-auto mb-8" />
              <p className="text-sm font-medium uppercase tracking-[0.2em] text-accent mb-4">
                Our Vision
              </p>
              <h2 className="font-[family-name:var(--font-playfair)] text-3xl md:text-4xl lg:text-5xl font-semibold text-white mb-8 leading-tight">
                &ldquo;To be the <span className="text-accent">Leading Construction Company</span> in the USA, delivering unmatched quality and service to our clients.&rdquo;
              </h2>
              <p className="text-lg text-white/70 max-w-2xl mx-auto">
                We are committed to exceeding expectations on every project, 
                building lasting relationships, and setting the standard for 
                commercial construction excellence.
              </p>
            </FadeIn>
          </div>
        </section>

        {/* Values - White Section */}
        <section className="py-20 lg:py-28 bg-white">
          <div className="container mx-auto px-4 lg:px-8">
            <FadeIn className="text-center mb-16">
              <p className="text-sm font-medium uppercase tracking-[0.2em] text-accent mb-4">
                Our Core Values
              </p>
              <h2 className="font-[family-name:var(--font-playfair)] text-3xl md:text-4xl font-semibold text-foreground mb-6">
                The Principles That Guide Us
              </h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                These values are the foundation of everything we do, from how we 
                treat our clients to how we approach every project.
              </p>
            </FadeIn>
            
            <StaggerContainer className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {companyValues.map((value) => {
                const Icon = valueIcons[value.title] || Shield
                return (
                  <FadeIn key={value.title}>
                    <div className="p-8 bg-white border border-border rounded-2xl h-full hover:border-accent/50 hover:shadow-xl transition-all duration-300 group">
                      <div className="w-14 h-14 bg-accent/10 rounded-xl flex items-center justify-center mb-6 group-hover:bg-accent group-hover:scale-110 transition-all duration-300">
                        <Icon className="w-7 h-7 text-accent group-hover:text-white transition-colors" />
                      </div>
                      <h3 className="font-[family-name:var(--font-playfair)] text-xl font-semibold text-foreground mb-3">
                        {value.title}
                      </h3>
                      <p className="text-muted-foreground leading-relaxed">
                        {value.description}
                      </p>
                    </div>
                  </FadeIn>
                )
              })}
            </StaggerContainer>
          </div>
        </section>

        {/* Why Choose Us */}
        <section className="py-20 lg:py-28 bg-secondary">
          <div className="container mx-auto px-4 lg:px-8">
            <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
              <FadeIn>
                <div className="grid grid-cols-2 gap-4">
                  <div className="aspect-[3/4] relative rounded-xl overflow-hidden">
                    <Image
                      src="/images/hotel-lobby.jpg"
                      alt="Hotel lobby construction"
                      fill
                      className="object-cover"
                    />
                  </div>
                  <div className="aspect-[3/4] relative rounded-xl overflow-hidden mt-8">
                    <Image
                      src="/images/drywall-work.jpg"
                      alt="Drywall installation"
                      fill
                      className="object-cover"
                    />
                  </div>
                </div>
              </FadeIn>
              
              <FadeIn delay={0.2}>
                <p className="text-sm font-medium uppercase tracking-[0.2em] text-accent mb-4">
                  Why Choose Us
                </p>
                <h2 className="font-[family-name:var(--font-playfair)] text-3xl md:text-4xl font-semibold text-foreground mb-6 leading-tight">
                  What Sets Us
                  <br />
                  <span className="text-accent">Apart</span>
                </h2>
                <div className="space-y-4 mb-8">
                  {[
                    'Over 37 years of commercial construction experience',
                    'Trusted by Marriott, Hilton, and industry leaders',
                    'Licensed and fully insured in NJ and NY',
                    'Dedicated project management from start to finish',
                    'Commitment to on-time, on-budget delivery',
                    'Skilled craftsmen with attention to detail'
                  ].map((item) => (
                    <div key={item} className="flex items-start gap-3">
                      <CheckCircle2 className="w-5 h-5 text-accent mt-0.5 shrink-0" />
                      <span className="text-muted-foreground">{item}</span>
                    </div>
                  ))}
                </div>
              </FadeIn>
            </div>
          </div>
        </section>

        {/* Testimonial */}
        <section className="py-20 lg:py-28 bg-white">
          <div className="container mx-auto px-4 lg:px-8">
            <FadeIn className="max-w-4xl mx-auto text-center">
              <Quote className="w-16 h-16 text-accent/20 mx-auto mb-8" />
              <blockquote className="font-[family-name:var(--font-playfair)] text-2xl md:text-3xl lg:text-4xl text-foreground mb-8 leading-relaxed">
                &ldquo;{testimonials[0].quote}&rdquo;
              </blockquote>
              <div className="flex items-center justify-center gap-4">
                <div className="w-14 h-14 bg-accent rounded-full flex items-center justify-center">
                  <span className="font-semibold text-white text-xl">
                    {testimonials[0].author.charAt(0)}
                  </span>
                </div>
                <div className="text-left">
                  <p className="font-semibold text-foreground text-lg">{testimonials[0].author}</p>
                  <p className="text-muted-foreground">{testimonials[0].title}, {testimonials[0].company}</p>
                </div>
              </div>
            </FadeIn>
          </div>
        </section>

        {/* CTA */}
        <section className="relative py-20 lg:py-28 overflow-hidden">
          <div className="absolute inset-0">
            <Image
              src="/images/hero-construction.jpg"
              alt="Commercial construction"
              fill
              className="object-cover"
            />
            <div className="absolute inset-0 bg-primary/90" />
          </div>
          
          <div className="container mx-auto px-4 lg:px-8 text-center relative z-10">
            <FadeIn>
              <p className="text-sm font-medium uppercase tracking-[0.2em] text-accent mb-4">
                Ready to Start?
              </p>
              <h2 className="font-[family-name:var(--font-playfair)] text-3xl md:text-4xl lg:text-5xl font-semibold text-white mb-6">
                Let&apos;s Build Something
                <br />
                <span className="text-accent">Extraordinary Together</span>
              </h2>
              <p className="text-lg text-white/80 mb-10 max-w-2xl mx-auto">
                Ready to discuss your next commercial construction project? 
                Contact our team for a free consultation and detailed proposal.
              </p>
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                <Button asChild size="lg" className="bg-accent hover:bg-accent/90 text-accent-foreground font-semibold text-lg px-8 h-14">
                  <Link href="/contact">
                    Request a Consultation
                    <ArrowRight className="ml-2 w-5 h-5" />
                  </Link>
                </Button>
                <Button asChild size="lg" variant="outline" className="border-white/30 text-white hover:bg-white/10 hover:border-white/50 bg-transparent text-lg px-8 h-14">
                  <Link href="/projects">
                    View Our Work
                  </Link>
                </Button>
              </div>
            </FadeIn>
          </div>
        </section>
        
        <MobileFloatingCTA />
      </main>
      <Footer />
    </>
  )
}
